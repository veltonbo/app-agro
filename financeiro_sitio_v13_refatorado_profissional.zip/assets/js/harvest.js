import { getState, mutate } from "./store.js";
import {
  allocateLatoes,
  allocatedForApanha,
  availableForApanha,
  availableLatoes,
  lotStats,
  nomeSafra,
  nomeTalhao,
  nomeTrabalhador,
  stockForSafra,
  workerStats
} from "./domain.js";
import {
  $, money, numberBR, dateBR, dateISO, escapeHTML, uid, toNumber, sortByDateDesc
} from "./utils.js";
import {
  setModal, showToast, options, field, textInput, numberInput, dateInput,
  selectInput, textareaInput, iconUse
} from "./ui.js";

function syncApanhaExpense(draft, apanha) {
  const worker = draft.trabalhadores.find((x) => x.id === apanha.trabalhadorId);
  const value = toNumber(apanha.latoes) * toNumber(apanha.valorLatao);
  if (!apanha.financeiroId) apanha.financeiroId = uid("lan");

  const existing = draft.lancamentos.find((x) => x.id === apanha.financeiroId);
  const next = {
    id: apanha.financeiroId,
    tipo: "despesa",
    data: apanha.data,
    valor: value,
    status: apanha.status || "pago",
    vencimento: existing?.vencimento || "",
    categoria: "Colheita",
    talhaoId: apanha.talhaoId || "",
    safraId: apanha.safraId || "",
    pessoaId: existing?.pessoaId || "",
    parcela: existing?.parcela || "",
    documento: existing?.documento || "",
    descricao: `Colheita - ${worker?.nome || "Colhedor"}`,
    obs: `${numberBR(apanha.latoes)} latões × ${money(apanha.valorLatao)}${apanha.obs ? ` • ${apanha.obs}` : ""}`,
    apanhaId: apanha.id
  };

  if (existing) Object.assign(existing, next);
  else draft.lancamentos.push(next);
}

function syncSaleRevenue(draft, sale, enabled) {
  const existingId = sale.financeiroId || "";
  if (!enabled) {
    if (existingId) draft.lancamentos = draft.lancamentos.filter((x) => x.id !== existingId);
    sale.financeiroId = "";
    return;
  }

  if (!sale.financeiroId) sale.financeiroId = uid("lan");
  const existing = draft.lancamentos.find((x) => x.id === sale.financeiroId);
  const next = {
    id: sale.financeiroId,
    tipo: "receita",
    data: sale.data,
    valor: sale.total,
    status: sale.status,
    vencimento: existing?.vencimento || "",
    categoria: "Venda de café",
    talhaoId: sale.talhaoId || "",
    safraId: sale.safraId || "",
    pessoaId: sale.pessoaId || existing?.pessoaId || "",
    parcela: existing?.parcela || "",
    documento: existing?.documento || "",
    descricao: `Venda de café${sale.comprador ? ` - ${sale.comprador}` : ""}`,
    obs: `${numberBR(sale.sacas)} sacas × ${money(sale.precoSaca)}${sale.obs ? ` • ${sale.obs}` : ""}`,
    vendaId: sale.id
  };
  if (existing) Object.assign(existing, next);
  else draft.lancamentos.push(next);
}

function activeSafra(state) {
  return state.safras.find((x) => x.id === state.safraAtivaId) || null;
}

export function renderHarvest() {
  const state = getState();
  const safra = activeSafra(state);

  $("harvestNoSafra").classList.toggle("hidden", Boolean(safra));
  $("harvestContent").classList.toggle("hidden", !safra);

  if (!safra) {
    $("harvestNoSafra").innerHTML = `
      <strong style="display:block;margin-bottom:5px;color:#47534b">Cadastre uma safra antes de lançar a colheita.</strong>
      A safra ativa define onde os novos latões, lotes, sacas e vendas serão organizados.
      <div style="margin-top:10px"><button class="btn primary" data-action="manage-safras">Cadastrar safra</button></div>
    `;
    return;
  }

  const apanhas = state.apanhas.filter((x) => x.safraId === safra.id);
  const lotes = state.lotes.filter((x) => x.safraId === safra.id);
  const colheitas = state.colheitas.filter((x) => x.safraId === safra.id);
  const vendas = state.vendas.filter((x) => x.safraId === safra.id);

  const totalLatoes = apanhas.reduce((s,x)=>s+toNumber(x.latoes),0);
  const disponiveis = apanhas.reduce((s,x)=>s+availableForApanha(state,x),0);
  const secando = lotes.filter((x)=>x.status!=="fechado").reduce((s,x)=>s+lotStats(state,x).latoes,0);
  const sacas = colheitas.reduce((s,x)=>s+toNumber(x.sacas),0);
  const custo = apanhas.reduce((s,x)=>s+toNumber(x.latoes)*toNumber(x.valorLatao),0);
  const fechados = lotes.filter((x)=>x.status==="fechado" && toNumber(x.sacas)>0);
  const custoFechados = fechados.reduce((s,x)=>s+lotStats(state,x).custoColheita,0);
  const sacasFechadas = fechados.reduce((s,x)=>s+toNumber(x.sacas),0);

  $("harvestMetrics").innerHTML = `
    <article class="harvest-kpi"><small>Latões colhidos</small><strong>${numberBR(totalLatoes)}</strong></article>
    <article class="harvest-kpi"><small>Disponíveis p/ secador</small><strong>${numberBR(disponiveis)}</strong></article>
    <article class="harvest-kpi"><small>Em secagem</small><strong>${numberBR(secando)}</strong></article>
    <article class="harvest-kpi featured"><small>Sacas prontas</small><strong>${numberBR(sacas)} sc</strong></article>
    <article class="harvest-kpi"><small>Custo da colheita</small><strong>${money(custo)}</strong></article>
    <article class="harvest-kpi"><small>Custo colheita / sc</small><strong>${money(sacasFechadas ? custoFechados/sacasFechadas : 0)}</strong></article>
  `;

  renderWorkers(state, safra.id);
  renderApanhas(state, safra.id);
  renderLots(state, safra.id);
  renderProduction(state, safra.id, colheitas, vendas);
}

function renderWorkers(state, safraId) {
  $("workerGrid").innerHTML = state.trabalhadores.length
    ? state.trabalhadores.map((worker) => {
        const stats = workerStats(state, worker.id, safraId);
        return `<article class="entity-card">
          <div class="entity-head">
            <div><h4>${escapeHTML(worker.nome)}</h4><p>${money(worker.valorLatao || 0)} por latão</p></div>
            <span class="badge">${numberBR(stats.latoes)} latões</span>
          </div>
          <div class="entity-stats">
            <div><small>Total</small><strong>${money(stats.total)}</strong></div>
            <div><small>Pago</small><strong>${money(stats.pago)}</strong></div>
            <div><small>A pagar</small><strong>${money(stats.pendente)}</strong></div>
          </div>
          <div class="entity-actions">
            <button class="btn small primary" data-action="worker-account" data-id="${escapeHTML(worker.id)}">Ver conta</button>
            <button class="btn small ghost" data-action="edit-worker" data-id="${escapeHTML(worker.id)}">Editar</button>
          </div>
        </article>`;
      }).join("")
    : `<div class="empty" style="grid-column:1/-1"><strong>Nenhum colhedor cadastrado.</strong>Cadastre a equipe antes de registrar latões.</div>`;
}

function apanhaStatus(state, item) {
  const allocated = allocatedForApanha(state, item.id);
  const available = Math.max(0, toNumber(item.latoes) - allocated);
  if (allocated <= 0.00001) return { label:"Aguardando secador", cls:"amber", allocated, available };
  if (available > 0.00001) return { label:"Parcialmente enviado", cls:"blue", allocated, available };
  return { label:"Enviado ao secador", cls:"", allocated, available:0 };
}

function renderApanhas(state, safraId) {
  const items = state.apanhas
    .filter((x)=>x.safraId===safraId)
    .sort((a,b)=>sortByDateDesc(a,b,"data"));

  $("harvestList").innerHTML = items.length
    ? items.map((item)=>{
      const st=apanhaStatus(state,item);
      const worker=nomeTrabalhador(state,item.trabalhadorId);
      const meta=[dateBR(item.data), item.talhaoId?nomeTalhao(state,item.talhaoId):"Sem talhão", `${money(item.valorLatao)}/latão`].join(" • ");
      return `<div class="list-row">
        <span class="row-icon coffee">${iconUse("i-coffee")}</span>
        <div class="row-main">
          <strong>${escapeHTML(worker)} • ${numberBR(item.latoes)} latões</strong>
          <small>${escapeHTML(meta)}</small>
          <small><span class="badge ${st.cls}">${st.label}</span> <span class="badge ${item.status==="pago"?"":"red"}">${item.status==="pago"?"Pago":"A pagar"}</span>${st.available>0?` <span class="badge amber">${numberBR(st.available)} disponíveis</span>`:""}</small>
        </div>
        <div class="row-value">
          <strong>${money(toNumber(item.latoes)*toNumber(item.valorLatao))}</strong>
          <div class="row-actions">
            <button class="icon-btn" data-action="toggle-harvest-paid" data-id="${escapeHTML(item.id)}" title="Alterar pagamento">${iconUse("i-check")}</button>
            ${st.allocated<=0.00001?`<button class="icon-btn" data-action="edit-harvest" data-id="${escapeHTML(item.id)}" title="Editar">${iconUse("i-edit")}</button><button class="icon-btn" data-action="delete-harvest" data-id="${escapeHTML(item.id)}" title="Excluir">${iconUse("i-trash")}</button>`:""}
          </div>
        </div>
      </div>`;
    }).join("")
    : `<div class="empty"><strong>Nenhum latão registrado nesta safra.</strong>Use “Registrar latões” para começar.</div>`;
}

function renderLots(state, safraId) {
  const items = state.lotes.filter((x)=>x.safraId===safraId).sort((a,b)=>sortByDateDesc(a,b,"dataEnvio"));
  $("lotGrid").innerHTML = items.length
    ? items.map((lote)=>{
      const stats=lotStats(state,lote);
      const source=lote.talhaoFiltro && lote.talhaoFiltro!=="todos" ? nomeTalhao(state,lote.talhaoFiltro) : "Geral / múltiplos";
      return `<article class="entity-card">
        <div class="entity-head">
          <div><h4>${escapeHTML(lote.nome||"Lote de secagem")}</h4><p>${dateBR(lote.dataEnvio)} • ${escapeHTML(source)}</p></div>
          <span class="badge ${lote.status==="fechado"?"":"amber"}">${lote.status==="fechado"?"Finalizado":"No secador"}</span>
        </div>
        <div class="entity-stats">
          <div><small>Latões</small><strong>${numberBR(stats.latoes)}</strong></div>
          <div><small>Sacas</small><strong>${lote.status==="fechado"?numberBR(stats.sacas):"—"}</strong></div>
          <div><small>Latões / sc</small><strong>${lote.status==="fechado"?numberBR(stats.latoesPorSaca):"—"}</strong></div>
        </div>
        <div class="entity-stats">
          <div><small>Custo colheita</small><strong>${money(stats.custoColheita)}</strong></div>
          <div><small>Custo / sc</small><strong>${lote.status==="fechado"?money(stats.custoColheitaPorSaca):"—"}</strong></div>
          <div><small>Colhedores</small><strong>${stats.trabalhadores}</strong></div>
        </div>
        <div class="entity-actions">
          ${lote.status==="fechado"?"":`<button class="btn small primary" data-action="close-lot" data-id="${escapeHTML(lote.id)}">Informar sacas</button><button class="btn small ghost" data-action="edit-lot" data-id="${escapeHTML(lote.id)}">Editar envio</button>`}
          <button class="btn small danger" data-action="delete-lot" data-id="${escapeHTML(lote.id)}">Excluir</button>
        </div>
      </article>`;
    }).join("")
    : `<div class="empty" style="grid-column:1/-1"><strong>Nenhum lote no secador.</strong>Informe a quantidade de latões que deseja enviar.</div>`;
}

function renderProduction(state, safraId, colheitas, vendas) {
  $("productionList").innerHTML = colheitas.length
    ? [...colheitas].sort((a,b)=>sortByDateDesc(a,b,"data")).map((item)=>{
      const lote=item.loteId?state.lotes.find((x)=>x.id===item.loteId):null;
      return `<div class="list-row">
        <span class="row-icon coffee">${iconUse("i-box")}</span>
        <div class="row-main"><strong>${numberBR(item.sacas)} sacas</strong><small>${dateBR(item.data)}${item.talhaoId?` • ${escapeHTML(nomeTalhao(state,item.talhaoId))}`:""}${lote?` • ${escapeHTML(lote.nome||"Secador")}`:""}</small></div>
        <div class="row-value"><small>${item.loteId?'<span class="badge">Do secador</span>':'Manual'}</small>${item.loteId?"":`<div class="row-actions"><button class="icon-btn" data-action="edit-production" data-id="${escapeHTML(item.id)}">${iconUse("i-edit")}</button><button class="icon-btn" data-action="delete-production" data-id="${escapeHTML(item.id)}">${iconUse("i-trash")}</button></div>`}</div>
      </div>`;
    }).join("")
    : `<div class="empty"><strong>Nenhuma saca produzida.</strong>Feche um lote do secador para adicionar a produção.</div>`;

  $("salesList").innerHTML = vendas.length
    ? [...vendas].sort((a,b)=>sortByDateDesc(a,b,"data")).map((item)=>{
      const meta=[dateBR(item.data), item.comprador||"", item.talhaoId?nomeTalhao(state,item.talhaoId):"", item.status==="pago"?"Recebido":"A receber"].filter(Boolean).join(" • ");
      return `<div class="list-row">
        <span class="row-icon blue">${iconUse("i-wallet")}</span>
        <div class="row-main"><strong>${numberBR(item.sacas)} sc • ${money(item.precoSaca)}/sc</strong><small>${escapeHTML(meta)}</small></div>
        <div class="row-value"><strong>${money(item.total)}</strong><div class="row-actions"><button class="icon-btn" data-action="edit-sale" data-id="${escapeHTML(item.id)}">${iconUse("i-edit")}</button><button class="icon-btn" data-action="delete-sale" data-id="${escapeHTML(item.id)}">${iconUse("i-trash")}</button></div></div>
      </div>`;
    }).join("")
    : `<div class="empty"><strong>Nenhuma venda nesta safra.</strong>As vendas dão baixa automática no estoque.</div>`;
}

export function openWorkerForm(id="") {
  const state=getState();
  const item=id?state.trabalhadores.find((x)=>x.id===id):null;
  if(id&&!item) return;

  const body=`<div class="form-grid">
    ${field("Nome do colhedor", textInput("nome",item?.nome||"",`required placeholder="Nome"`))}
    ${field("Valor padrão por latão", numberInput("valorLatao",item?.valorLatao??"",`min="0" required`))}
    ${field("Observação", textareaInput("obs",item?.obs||""),{full:true})}
  </div>`;

  setModal({
    eyebrow:"EQUIPE",
    title:item?"Editar colhedor":"Novo colhedor",
    body,submitLabel:"Salvar colhedor",
    onSubmit:async(fd)=>{
      const nome=String(fd.get("nome")||"").trim();
      if(!nome) throw new Error("Informe o nome do colhedor.");
      const valor=toNumber(fd.get("valorLatao"));
      mutate((draft)=>{
        const current=item?draft.trabalhadores.find((x)=>x.id===item.id):null;
        const next={id:current?.id||uid("trab"),nome,valorLatao:valor,obs:String(fd.get("obs")||"").trim()};
        if(current) Object.assign(current,next); else draft.trabalhadores.push(next);
      });
      showToast("Colhedor salvo.");
    }
  });
}

export function openWorkerAccount(id) {
  const state=getState();
  const worker=state.trabalhadores.find((x)=>x.id===id);
  if(!worker) return;
  const safraId=state.safraAtivaId||"todos";
  const stats=workerStats(state,id,safraId);
  const rows=state.apanhas
    .filter((x)=>x.trabalhadorId===id&&(safraId==="todos"||x.safraId===safraId))
    .sort((a,b)=>sortByDateDesc(a,b,"data"));

  const body=`
    <div class="inline-kpis">
      <article><small>Latões</small><strong>${numberBR(stats.latoes)}</strong></article>
      <article><small>Total</small><strong>${money(stats.total)}</strong></article>
      <article><small>Pago</small><strong>${money(stats.pago)}</strong></article>
      <article><small>A pagar</small><strong>${money(stats.pendente)}</strong></article>
    </div>
    <div class="list-card">${rows.length?rows.map((x)=>`<div class="list-row"><span class="row-icon coffee">${iconUse("i-coffee")}</span><div class="row-main"><strong>${dateBR(x.data)} • ${numberBR(x.latoes)} latões</strong><small>${escapeHTML(x.talhaoId?nomeTalhao(state,x.talhaoId):"Sem talhão")} • ${money(x.valorLatao)}/latão</small></div><div class="row-value"><strong>${money(toNumber(x.latoes)*toNumber(x.valorLatao))}</strong><small>${x.status==="pago"?"Pago":"A pagar"}</small></div></div>`).join(""):`<div class="empty">Nenhum registro nesta safra.</div>`}</div>
  `;

  setModal({
    eyebrow:state.safraAtivaId?nomeSafra(state,state.safraAtivaId):"TODAS AS SAFRAS",
    title:`Conta de ${worker.nome}`,
    body,
    submitLabel:stats.pendente>0?"Marcar pendências como pagas":"",
    cancelLabel:"Fechar",
    onSubmit:stats.pendente>0?async()=>{
      mutate((draft)=>{
        draft.apanhas.filter((x)=>x.trabalhadorId===id&&(safraId==="todos"||x.safraId===safraId)&&x.status!=="pago").forEach((apanha)=>{
          apanha.status="pago";
          syncApanhaExpense(draft,apanha);
        });
      });
      showToast("Pendências marcadas como pagas.");
    }:null
  });
}

export function deleteWorker(id) {
  const state=getState();
  if(state.apanhas.some((x)=>x.trabalhadorId===id)){showToast("Esse colhedor possui registros de colheita.");return}
  if(!confirm("Excluir este colhedor?"))return;
  mutate((draft)=>{draft.trabalhadores=draft.trabalhadores.filter((x)=>x.id!==id)});
  showToast("Colhedor excluído.");
}

export function openApanhaForm(id="") {
  const state=getState();
  const safra=activeSafra(state);
  if(!safra){showToast("Cadastre uma safra ativa primeiro.");return}
  if(!state.trabalhadores.length){showToast("Cadastre um colhedor primeiro.");openWorkerForm();return}

  const item=id?state.apanhas.find((x)=>x.id===id):null;
  if(id&&!item)return;
  if(item&&allocatedForApanha(state,item.id)>0.00001){showToast("Esse registro já possui latões enviados ao secador.");return}

  const workerId=item?.trabalhadorId||state.trabalhadores[0].id;
  const worker=state.trabalhadores.find((x)=>x.id===workerId);
  const body=`<div class="form-grid">
    ${field("Data",dateInput("data",item?.data||dateISO()))}
    ${field("Colhedor",selectInput("trabalhadorId",options(state.trabalhadores,workerId)))}
    ${field("Talhão",selectInput("talhaoId",options(state.talhoes,item?.talhaoId||"",{includeEmpty:true,emptyLabel:"Sem talhão"})))}
    ${field("Safra",selectInput("safraId",options(state.safras,item?.safraId||safra.id),`disabled`),{hint:"A colheita é registrada na safra ativa."})}
    ${field("Latões colhidos",numberInput("latoes",item?.latoes??"",`min="0.01" required`))}
    ${field("Valor por latão",numberInput("valorLatao",item?.valorLatao??worker?.valorLatao??"",`min="0" required`))}
    ${field("Pagamento",selectInput("status",`<option value="pago"${item?.status==="pago"||!item?" selected":""}>Pago</option><option value="pendente"${item?.status!=="pago"&&item?" selected":""}>A pagar</option>`))}
    ${field("Observação",textareaInput("obs",item?.obs||""),{full:true})}
  </div>
  <div id="harvestFormTotal" class="form-section"><h4>Total do colhedor</h4><strong>${money(toNumber(item?.latoes)*toNumber(item?.valorLatao))}</strong></div>`;

  setModal({
    eyebrow:"COLHEITA",
    title:item?"Editar registro de latões":"Registrar latões",
    body,submitLabel:"Salvar colheita",
    onSubmit:async(fd)=>{
      const latoes=toNumber(fd.get("latoes")), valor=toNumber(fd.get("valorLatao"));
      if(latoes<=0)throw new Error("Informe a quantidade de latões.");
      mutate((draft)=>{
        const current=item?draft.apanhas.find((x)=>x.id===item.id):null;
        const next={
          id:current?.id||uid("apanha"),
          data:String(fd.get("data")||dateISO()),
          trabalhadorId:String(fd.get("trabalhadorId")||""),
          talhaoId:String(fd.get("talhaoId")||""),
          safraId:safra.id,
          latoes,
          valorLatao:valor,
          status:String(fd.get("status")||"pago"),
          obs:String(fd.get("obs")||"").trim(),
          financeiroId:current?.financeiroId||""
        };
        if(current)Object.assign(current,next);else draft.apanhas.push(next);
        const target=current||draft.apanhas[draft.apanhas.length-1];
        syncApanhaExpense(draft,target);
      });
      showToast("Latões registrados e custo lançado no financeiro.");
    }
  });

  const form=$("modalForm");
  const refreshTotal=()=>{
    const l=toNumber(form.elements.latoes?.value),v=toNumber(form.elements.valorLatao?.value);
    const el=$("harvestFormTotal"); if(el)el.innerHTML=`<h4>Total do colhedor</h4><strong>${money(l*v)}</strong>`;
  };
  form.elements.latoes?.addEventListener("input",refreshTotal);
  form.elements.valorLatao?.addEventListener("input",refreshTotal);
  form.elements.trabalhadorId?.addEventListener("change",(e)=>{
    const w=getState().trabalhadores.find((x)=>x.id===e.target.value);
    if(w&&form.elements.valorLatao)form.elements.valorLatao.value=w.valorLatao||0;
    refreshTotal();
  });
}

export function toggleApanhaPaid(id){
  mutate((draft)=>{
    const item=draft.apanhas.find((x)=>x.id===id);if(!item)return;
    item.status=item.status==="pago"?"pendente":"pago";
    syncApanhaExpense(draft,item);
  });
  showToast("Pagamento atualizado.");
}

export function deleteApanha(id){
  const state=getState(),item=state.apanhas.find((x)=>x.id===id);if(!item)return;
  if(allocatedForApanha(state,id)>0.00001){showToast("Há latões deste registro já enviados ao secador.");return}
  if(!confirm("Excluir este registro de colheita?"))return;
  mutate((draft)=>{
    if(item.financeiroId)draft.lancamentos=draft.lancamentos.filter((x)=>x.id!==item.financeiroId);
    draft.apanhas=draft.apanhas.filter((x)=>x.id!==id);
  });
  showToast("Registro excluído.");
}

export function openLotForm(id=""){
  const state=getState(),safra=activeSafra(state);
  if(!safra){showToast("Cadastre uma safra ativa primeiro.");return}
  const item=id?state.lotes.find((x)=>x.id===id):null;
  if(item?.status==="fechado"){showToast("Este lote já foi finalizado.");return}
  const currentQty=item?lotStats(state,item).latoes:0;
  const talhao=item?.talhaoFiltro||"todos";
  const available=availableLatoes(state,{safraId:safra.id,talhaoId:talhao,ignoreLoteId:item?.id||""});

  const body=`<div class="form-grid">
    ${field("Data de envio",dateInput("dataEnvio",item?.dataEnvio||dateISO()))}
    ${field("Identificação do lote",textInput("nome",item?.nome||"",`placeholder="Ex.: Secagem 01"`))}
    ${field("Talhão de origem",selectInput("talhaoFiltro",`<option value="todos">Todos os talhões</option>${options(state.talhoes,talhao)}`))}
    ${field("Quantidade de latões",numberInput("quantidade",currentQty||"",`min="0.01" required`))}
    ${field("Observação",textareaInput("obs",item?.obs||""),{full:true})}
  </div>
  <div id="lotPreview" class="inline-kpis"></div>
  <div class="form-hint">O app utiliza automaticamente os latões disponíveis mais antigos. Um registro pode ser usado parcialmente e o restante continua disponível.</div>`;

  setModal({
    eyebrow:"SECADOR",
    title:item?"Editar envio ao secador":"Enviar ao secador",
    body,submitLabel:"Salvar envio",
    onSubmit:async(fd)=>{
      const qtd=toNumber(fd.get("quantidade")),tal=String(fd.get("talhaoFiltro")||"todos");
      const availableNow=availableLatoes(getState(),{safraId:safra.id,talhaoId:tal,ignoreLoteId:item?.id||""});
      if(qtd<=0)throw new Error("Informe a quantidade de latões.");
      if(qtd>availableNow+0.0001)throw new Error(`Há somente ${numberBR(availableNow)} latões disponíveis.`);
      const allocation=allocateLatoes(getState(),qtd,{safraId:safra.id,talhaoId:tal,ignoreLoteId:item?.id||""});
      if(allocation.faltante>0.0001)throw new Error("Não foi possível separar essa quantidade.");
      mutate((draft)=>{
        const current=item?draft.lotes.find((x)=>x.id===item.id):null;
        const next={
          id:current?.id||uid("lote"),
          nome:String(fd.get("nome")||"").trim()||`Secagem ${draft.lotes.length+1}`,
          dataEnvio:String(fd.get("dataEnvio")||dateISO()),
          talhaoFiltro:tal,
          safraId:safra.id,
          alocacoes:allocation.alocacoes,
          status:"secando",
          obs:String(fd.get("obs")||"").trim(),
          sacas:current?.sacas||0,
          dataFechamento:current?.dataFechamento||"",
          colheitaId:current?.colheitaId||"",
          obsFinal:current?.obsFinal||""
        };
        if(current)Object.assign(current,next);else draft.lotes.push(next);
      });
      showToast(`${numberBR(qtd)} latões enviados ao secador.`);
    }
  });

  const form=$("modalForm");
  const preview=()=>{
    const qtd=toNumber(form.elements.quantidade?.value);
    const tal=form.elements.talhaoFiltro?.value||"todos";
    const st=getState();
    const avail=availableLatoes(st,{safraId:safra.id,talhaoId:tal,ignoreLoteId:item?.id||""});
    const alloc=allocateLatoes(st,qtd,{safraId:safra.id,talhaoId:tal,ignoreLoteId:item?.id||""});
    const workers=new Set();
    let cost=0;
    alloc.alocacoes.forEach((al)=>{
      const a=st.apanhas.find((x)=>x.id===al.apanhaId);if(!a)return;
      workers.add(a.trabalhadorId);cost+=toNumber(al.latoes)*toNumber(a.valorLatao);
    });
    $("lotPreview").innerHTML=`<article><small>Disponíveis</small><strong>${numberBR(avail)}</strong></article><article><small>Enviar</small><strong>${numberBR(Math.min(qtd,avail))}</strong></article><article><small>Custo da colheita</small><strong>${money(cost)}</strong></article><article><small>Colhedores envolvidos</small><strong>${workers.size}</strong></article>`;
  };
  form.elements.quantidade?.addEventListener("input",preview);
  form.elements.talhaoFiltro?.addEventListener("change",preview);
  preview();
}

export function openCloseLot(id){
  const state=getState(),item=state.lotes.find((x)=>x.id===id);if(!item)return;
  const stats=lotStats(state,item);
  const body=`<div class="form-grid">
    ${field("Data de fechamento",dateInput("dataFechamento",item.dataFechamento||dateISO()))}
    ${field("Sacas após secar e limpar",numberInput("sacas",item.sacas||"",`min="0.01" required`))}
    ${field("Observação final",textareaInput("obsFinal",item.obsFinal||""),{full:true})}
  </div>
  <div id="closeLotPreview" class="inline-kpis"></div>`;

  setModal({
    eyebrow:"SECADOR",
    title:`Finalizar ${item.nome||"lote"}`,
    body,submitLabel:"Confirmar sacas",
    onSubmit:async(fd)=>{
      const sacas=toNumber(fd.get("sacas"));if(sacas<=0)throw new Error("Informe quantas sacas o lote rendeu.");
      mutate((draft)=>{
        const lote=draft.lotes.find((x)=>x.id===id);if(!lote)return;
        lote.status="fechado";lote.sacas=sacas;lote.dataFechamento=String(fd.get("dataFechamento")||dateISO());lote.obsFinal=String(fd.get("obsFinal")||"").trim();
        if(!lote.colheitaId)lote.colheitaId=uid("prod");
        const s=lotStats(draft,lote);
        const talhaoIds=s.talhoes;
        const prod={
          id:lote.colheitaId,data:lote.dataFechamento,talhaoId:talhaoIds.length===1?talhaoIds[0]:"",
          safraId:lote.safraId||"",sacas,safra:nomeSafra(draft,lote.safraId),
          obs:`Produção final do ${lote.nome}. ${numberBR(s.latoes)} latões após secagem e limpeza.`,loteId:lote.id
        };
        const existing=draft.colheitas.find((x)=>x.id===prod.id);
        if(existing)Object.assign(existing,prod);else draft.colheitas.push(prod);
      });
      showToast("Lote finalizado e sacas adicionadas ao estoque.");
    }
  });

  const form=$("modalForm");
  const preview=()=>{
    const sacas=toNumber(form.elements.sacas?.value);
    $("closeLotPreview").innerHTML=`<article><small>Latões</small><strong>${numberBR(stats.latoes)}</strong></article><article><small>Latões / saca</small><strong>${sacas?numberBR(stats.latoes/sacas):"—"}</strong></article><article><small>Custo colheita / sc</small><strong>${sacas?money(stats.custoColheita/sacas):"—"}</strong></article><article><small>Custo da colheita</small><strong>${money(stats.custoColheita)}</strong></article>`;
  };
  form.elements.sacas?.addEventListener("input",preview);preview();
}

export function deleteLot(id){
  const state=getState(),item=state.lotes.find((x)=>x.id===id);if(!item)return;
  if(!confirm("Excluir este lote? Os latões voltarão a ficar disponíveis."))return;
  mutate((draft)=>{
    if(item.colheitaId)draft.colheitas=draft.colheitas.filter((x)=>x.id!==item.colheitaId);
    draft.lotes=draft.lotes.filter((x)=>x.id!==id);
  });
  showToast("Lote excluído.");
}

export function openProductionForm(id=""){
  const state=getState(),safra=activeSafra(state);
  if(!safra){showToast("Cadastre uma safra ativa primeiro.");return}
  const item=id?state.colheitas.find((x)=>x.id===id):null;
  if(item?.loteId){showToast("Essa produção veio do secador; altere o lote correspondente.");return}
  const body=`<div class="form-grid">
    ${field("Data",dateInput("data",item?.data||dateISO()))}
    ${field("Talhão",selectInput("talhaoId",options(state.talhoes,item?.talhaoId||"",{includeEmpty:true,emptyLabel:"Sem talhão"})))}
    ${field("Sacas produzidas",numberInput("sacas",item?.sacas??"",`min="0.01" required`))}
    ${field("Safra",selectInput("safraId",options(state.safras,item?.safraId||safra.id),`disabled`))}
    ${field("Observação",textareaInput("obs",item?.obs||""),{full:true})}
  </div>`;
  setModal({
    eyebrow:"PRODUÇÃO",title:item?"Editar produção":"Registrar produção manual",body,submitLabel:"Salvar produção",
    onSubmit:async(fd)=>{
      const sacas=toNumber(fd.get("sacas"));if(sacas<=0)throw new Error("Informe a quantidade de sacas.");
      mutate((draft)=>{
        const current=item?draft.colheitas.find((x)=>x.id===item.id):null;
        const next={id:current?.id||uid("prod"),data:String(fd.get("data")||dateISO()),talhaoId:String(fd.get("talhaoId")||""),safraId:safra.id,sacas,safra:safra.nome,obs:String(fd.get("obs")||"").trim()};
        if(current)Object.assign(current,next);else draft.colheitas.push(next);
      });
      showToast("Produção salva.");
    }
  });
}

export function deleteProduction(id){
  const state=getState(),item=state.colheitas.find((x)=>x.id===id);if(!item)return;
  if(item.loteId){showToast("Essa produção foi gerada por um lote do secador.");return}
  if(!confirm("Excluir este registro de produção?"))return;
  mutate((draft)=>{draft.colheitas=draft.colheitas.filter((x)=>x.id!==id)});
}

export function openSaleForm(id="",prefillPrice=null){
  const state=getState(),safra=activeSafra(state);
  if(!safra){showToast("Cadastre uma safra ativa primeiro.");return}
  const item=id?state.vendas.find((x)=>x.id===id):null;if(id&&!item)return;
  const safraId=item?.safraId||safra.id;
  const available=stockForSafra(state,safraId,item?.id||"");
  const people=state.pessoas.filter((x)=>["comprador","ambos"].includes(x.tipo));
  const body=`<div class="form-grid">
    ${field("Data",dateInput("data",item?.data||dateISO()))}
    ${field("Safra",selectInput("safraId",options(state.safras,safraId)))}
    ${field("Talhão",selectInput("talhaoId",options(state.talhoes,item?.talhaoId||"",{includeEmpty:true,emptyLabel:"Sem talhão / lote misto"})))}
    ${field("Sacas vendidas",numberInput("sacas",item?.sacas??"",`min="0.01" required`))}
    ${field("Preço por saca",numberInput("precoSaca",item?.precoSaca??prefillPrice??"",`min="0.01" required`),{hint:"Você pode usar a cotação regional como referência."})}
    ${field("Comprador cadastrado",selectInput("pessoaId",options(people,item?.pessoaId||"",{includeEmpty:true,emptyLabel:"Não selecionado"})))}
    ${field("Nome do comprador",textInput("comprador",item?.comprador||"",`placeholder="Caso não esteja cadastrado"`))}
    ${field("Status financeiro",selectInput("status",`<option value="pago"${item?.status==="pago"||!item?" selected":""}>Recebido</option><option value="pendente"${item?.status!=="pago"&&item?" selected":""}>A receber</option>`))}
    ${field("Observação",textareaInput("obs",item?.obs||""),{full:true})}
  </div>
  <label class="check-row"><input name="gerarReceita" type="checkbox"${item?.financeiroId||!item?" checked":""}> Criar/atualizar automaticamente uma receita no financeiro.</label>
  <div id="salePreview" class="inline-kpis"></div>`;

  setModal({
    eyebrow:"VENDA",title:item?"Editar venda":"Registrar venda",body,submitLabel:"Salvar venda",
    onSubmit:async(fd)=>{
      const qty=toNumber(fd.get("sacas")),price=toNumber(fd.get("precoSaca")),sid=String(fd.get("safraId")||safra.id);
      if(qty<=0||price<=0)throw new Error("Informe sacas e preço por saca.");
      const avail=stockForSafra(getState(),sid,item?.id||"");
      if(qty>avail+0.0001)throw new Error(`Estoque insuficiente. Disponível: ${numberBR(avail)} sacas.`);
      mutate((draft)=>{
        const current=item?draft.vendas.find((x)=>x.id===item.id):null;
        const personId=String(fd.get("pessoaId")||"");
        const person=draft.pessoas.find((x)=>x.id===personId);
        const next={
          id:current?.id||uid("venda"),data:String(fd.get("data")||dateISO()),talhaoId:String(fd.get("talhaoId")||""),
          safraId:sid,sacas:qty,precoSaca:price,total:qty*price,pessoaId:personId,
          comprador:String(fd.get("comprador")||"").trim()||person?.nome||"",status:String(fd.get("status")||"pago"),
          obs:String(fd.get("obs")||"").trim(),financeiroId:current?.financeiroId||""
        };
        if(current)Object.assign(current,next);else draft.vendas.push(next);
        syncSaleRevenue(draft,current||draft.vendas[draft.vendas.length-1],fd.get("gerarReceita")==="on");
      });
      showToast("Venda salva e estoque atualizado.");
    }
  });

  const form=$("modalForm");
  const preview=()=>{
    const sid=form.elements.safraId?.value||safra.id;
    const avail=stockForSafra(getState(),sid,item?.id||"");
    const qty=toNumber(form.elements.sacas?.value),price=toNumber(form.elements.precoSaca?.value);
    $("salePreview").innerHTML=`<article><small>Estoque disponível</small><strong>${numberBR(avail)} sc</strong></article><article><small>Quantidade</small><strong>${numberBR(qty)} sc</strong></article><article><small>Preço / sc</small><strong>${money(price)}</strong></article><article><small>Total</small><strong>${money(qty*price)}</strong></article>`;
  };
  ["safraId","sacas","precoSaca"].forEach((name)=>form.elements[name]?.addEventListener("input",preview));
  form.elements.safraId?.addEventListener("change",preview);
  preview();
}

export function deleteSale(id){
  const state=getState(),item=state.vendas.find((x)=>x.id===id);if(!item)return;
  if(!confirm("Excluir esta venda? As sacas voltarão para o estoque."))return;
  mutate((draft)=>{
    if(item.financeiroId)draft.lancamentos=draft.lancamentos.filter((x)=>x.id!==item.financeiroId);
    draft.vendas=draft.vendas.filter((x)=>x.id!==id);
  });
  showToast("Venda excluída e estoque restaurado.");
}
