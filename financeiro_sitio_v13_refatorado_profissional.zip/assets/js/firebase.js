import { initializeApp } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js";
import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";
import {
  getDatabase,
  ref,
  get,
  set,
  onValue,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-database.js";

import { FIREBASE_CONFIG, CLOUD_ROOT } from "./config.js";
import {
  emptyState,
  getStateClone,
  replaceState,
  resetState,
  subscribe
} from "./store.js";

const app = initializeApp(FIREBASE_CONFIG);
const auth = getAuth(app);
const db = getDatabase(app);

let currentUser = null;
let stateRef = null;
let unsubscribeState = null;
let unsubscribeConnected = null;
let saveTimer = null;
let applyingRemote = false;
let statusHandler = () => {};
let userHandler = () => {};
let started = false;

function localKey(uid) {
  return `financeiro_sitio_${uid}`;
}

function saveLocal(uid, state) {
  if (!uid) return;
  try {
    localStorage.setItem(localKey(uid), JSON.stringify(state));
  } catch (error) {
    console.warn("Não foi possível salvar cache local:", error);
  }
}

function loadLocal(uid) {
  if (!uid) return null;
  try {
    const raw = localStorage.getItem(localKey(uid));
    return raw ? JSON.parse(raw) : null;
  } catch (error) {
    console.warn("Cache local inválido:", error);
    return null;
  }
}

function status(text, kind = "normal") {
  statusHandler({ text, kind });
}

export function authErrorMessage(error) {
  const messages = {
    "auth/invalid-credential": "E-mail ou senha incorretos.",
    "auth/email-already-in-use": "Esse e-mail já está cadastrado.",
    "auth/invalid-email": "E-mail inválido.",
    "auth/weak-password": "A senha precisa ter pelo menos 6 caracteres.",
    "auth/too-many-requests": "Muitas tentativas. Tente novamente mais tarde.",
    "auth/network-request-failed": "Falha de internet. Verifique a conexão.",
    "auth/user-disabled": "Esta conta está desativada."
  };
  return messages[error?.code] || "Não foi possível concluir a operação.";
}

export async function login(email, password) {
  return signInWithEmailAndPassword(auth, email, password);
}

export async function register(email, password) {
  return createUserWithEmailAndPassword(auth, email, password);
}

export async function logout() {
  return signOut(auth);
}

async function sendNow() {
  if (!currentUser || !stateRef || applyingRemote) return;
  status("sincronizando...", "loading");

  const payload = {
    ...getStateClone(),
    updatedAt: serverTimestamp(),
    updatedBy: currentUser.uid
  };

  await set(stateRef, payload);
  status("sincronizado", "ok");
}

function queueSave() {
  if (!currentUser || !stateRef || applyingRemote) return;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    sendNow().catch((error) => {
      console.error("Erro ao sincronizar:", error);
      status(
        String(error?.message || "").toLowerCase().includes("permission")
          ? "permissão negada"
          : "erro ao sincronizar",
        "error"
      );
    });
  }, 450);
}

function cleanupRealtime() {
  if (unsubscribeState) {
    unsubscribeState();
    unsubscribeState = null;
  }
  if (unsubscribeConnected) {
    unsubscribeConnected();
    unsubscribeConnected = null;
  }
  clearTimeout(saveTimer);
}

async function connectUser(user) {
  cleanupRealtime();
  currentUser = user;
  userHandler(user);

  if (!user) {
    stateRef = null;
    resetState("system");
    status("aguardando login");
    return;
  }

  stateRef = ref(db, `${CLOUD_ROOT}/${user.uid}/estado`);
  status("carregando seus dados...", "loading");

  // Cache do próprio UID apenas para uma abertura mais rápida / offline.
  const cached = loadLocal(user.uid);
  if (cached) replaceState(cached, "cache");

  try {
    const snapshot = await get(stateRef);

    if (snapshot.exists()) {
      applyingRemote = true;
      try {
        replaceState(snapshot.val(), "remote");
        saveLocal(user.uid, getStateClone());
      } finally {
        applyingRemote = false;
      }
    } else {
      // Conta nova: começa realmente zerada.
      // Se o mesmo UID já tinha cache local, preservamos esse cache; caso contrário, estrutura vazia.
      const initial = cached || emptyState();
      applyingRemote = true;
      try {
        replaceState(initial, "remote");
      } finally {
        applyingRemote = false;
      }
      await sendNow();
    }

    status("conectado em tempo real", "ok");

    unsubscribeState = onValue(
      stateRef,
      (snap) => {
        if (!snap.exists() || applyingRemote) return;
        applyingRemote = true;
        try {
          replaceState(snap.val(), "remote");
          saveLocal(user.uid, getStateClone());
          status("atualizado em tempo real", "ok");
        } finally {
          applyingRemote = false;
        }
      },
      (error) => {
        console.error("Erro no listener Firebase:", error);
        status(
          String(error?.message || "").toLowerCase().includes("permission")
            ? "permissão negada"
            : "erro de conexão",
          "error"
        );
      }
    );

    unsubscribeConnected = onValue(ref(db, ".info/connected"), (snap) => {
      status(snap.val() === true ? "conectado em tempo real" : "offline", snap.val() === true ? "ok" : "offline");
    });
  } catch (error) {
    console.error("Erro ao carregar dados do Firebase:", error);
    if (cached) {
      status("offline • usando dados salvos", "offline");
    } else {
      status(
        String(error?.message || "").toLowerCase().includes("permission")
          ? "permissão negada"
          : "erro ao carregar dados",
        "error"
      );
    }
  }
}

export function startFirebase({ onStatus = () => {}, onUser = () => {} } = {}) {
  if (started) return;
  started = true;
  statusHandler = onStatus;
  userHandler = onUser;

  subscribe((state, source) => {
    if (!currentUser) return;
    saveLocal(currentUser.uid, state);
    if (source === "local") queueSave();
  });

  onAuthStateChanged(auth, connectUser);
}

export function currentFirebaseUser() {
  return currentUser;
}

export const cloudSync = {
  queue: queueSave,
  sendNow
};
