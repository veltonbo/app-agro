export const APP_VERSION = "13.0.0";
export const APP_NAME = "Financeiro do Sítio";

export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyD773S1h91tovlKTPbaeAZbN2o1yxROcOc",
  authDomain: "manej-cafe.firebaseapp.com",
  databaseURL: "https://manej-cafe-default-rtdb.firebaseio.com",
  projectId: "manej-cafe",
  storageBucket: "manej-cafe.firebasestorage.app",
  messagingSenderId: "808931200634",
  appId: "1:808931200634:web:71357af2ff0dc2e4f5f5c3"
};

export const CLOUD_ROOT = "financeiroSitio/users";

export const DEFAULT_REVENUE_CATEGORIES = [
  "Venda de café",
  "Venda de mudas",
  "Venda de insumos / materiais",
  "Venda de máquinas / equipamentos",
  "Prestação de serviço",
  "Arrendamento / aluguel",
  "Reembolso",
  "Outras receitas"
];

export const DEFAULT_EXPENSE_CATEGORIES = [
  "Adubo / Fertilizantes",
  "Corretivos / Calcário / Gesso",
  "Defensivos",
  "Herbicidas",
  "Biológicos",
  "Mudas / Plantio",
  "Mão de obra",
  "Colheita",
  "Secagem / Beneficiamento",
  "Combustível / Lubrificantes",
  "Energia elétrica",
  "Irrigação",
  "Manutenção",
  "Peças / Reposição",
  "Máquinas / Equipamentos",
  "Frete / Transporte",
  "Sacaria / Embalagens",
  "Serviços terceirizados",
  "Alimentação da equipe",
  "Arrendamento / Aluguel",
  "Impostos / Taxas",
  "Documentação / Contabilidade",
  "Construções / Benfeitorias",
  "Outras despesas"
];

export const QUOTE_DEFAULT_DISCOUNT = 80;
export const QUOTE_REFRESH_MS = 15 * 60 * 1000;
export const QUOTE_MIN_RETRY_MS = 5 * 60 * 1000;
