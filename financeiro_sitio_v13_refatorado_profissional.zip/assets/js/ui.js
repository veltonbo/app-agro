import { $, escapeHTML } from "./utils.js";

let modalSubmitHandler = null;
let toastTimer = null;

export function showToast(message, duration = 2800) {
  const toast = $("toast");
  if (!toast) return;
  toast.textContent = message;
  toast.classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.add("hidden"), duration);
}

export function setModal({
  title,
  eyebrow = "",
  body = "",
  submitLabel = "",
  cancelLabel = "Cancelar",
  wide = false,
  onSubmit = null,
  footer = true
}) {
  const modal = $("modal");
  const panel = $("modalPanel");
  const form = $("modalForm");

  $("modalTitle").textContent = title || "Detalhes";
  $("modalEyebrow").textContent = eyebrow || "";
  $("modalBody").innerHTML = body || "";

  panel.classList.toggle("wide", wide);

  const footerEl = $("modalFooter");
  if (footer) {
    footerEl.innerHTML = `
      <button class="btn ghost" type="button" data-action="close-modal">${escapeHTML(cancelLabel)}</button>
      ${submitLabel ? `<button class="btn primary" type="submit">${escapeHTML(submitLabel)}</button>` : ""}
    `;
    footerEl.classList.remove("hidden");
  } else {
    footerEl.innerHTML = "";
    footerEl.classList.add("hidden");
  }

  modalSubmitHandler = onSubmit;
  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";

  setTimeout(() => {
    const focus = $("modalBody").querySelector("input:not([type=hidden]),select,textarea,button");
    focus?.focus?.();
  }, 30);

  form.onsubmit = async (event) => {
    event.preventDefault();
    if (!modalSubmitHandler) return;
    const submitButton = footerEl.querySelector('button[type="submit"]');
    if (submitButton) submitButton.disabled = true;
    try {
      const shouldClose = await modalSubmitHandler(new FormData(form), form);
      if (shouldClose !== false) closeModal();
    } catch (error) {
      console.error(error);
      showToast(error?.message || "Não foi possível salvar.");
    } finally {
      if (submitButton) submitButton.disabled = false;
    }
  };
}

export function closeModal() {
  const modal = $("modal");
  modal.classList.add("hidden");
  modal.setAttribute("aria-hidden", "true");
  $("modalBody").onclick = null;
  $("modalBody").innerHTML = "";
  $("modalFooter").innerHTML = "";
  $("modalForm").onsubmit = null;
  modalSubmitHandler = null;
  document.body.style.overflow = "";
}

export function setPage(name) {
  document.querySelectorAll("[data-page-panel]").forEach((el) => {
    el.classList.toggle("active", el.dataset.pagePanel === name);
  });
  document.querySelectorAll(".nav-btn[data-page]").forEach((el) => {
    el.classList.toggle("active", el.dataset.page === name);
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
}

export function options(items, selected = "", {
  includeEmpty = false,
  emptyLabel = "Selecione",
  getValue = (x) => x.id,
  getLabel = (x) => x.nome
} = {}) {
  const rows = [];
  if (includeEmpty) rows.push(`<option value="">${escapeHTML(emptyLabel)}</option>`);
  for (const item of items) {
    const value = String(getValue(item) ?? "");
    const label = String(getLabel(item) ?? "");
    rows.push(`<option value="${escapeHTML(value)}"${value === String(selected ?? "") ? " selected" : ""}>${escapeHTML(label)}</option>`);
  }
  return rows.join("");
}

export function field(label, input, { full = false, hint = "" } = {}) {
  return `<div class="field${full ? " full" : ""}"><label>${escapeHTML(label)}</label>${input}${hint ? `<div class="form-hint">${escapeHTML(hint)}</div>` : ""}</div>`;
}

export function textInput(name, value = "", attrs = "") {
  return `<input name="${escapeHTML(name)}" value="${escapeHTML(value ?? "")}" ${attrs}>`;
}

export function numberInput(name, value = "", attrs = "") {
  const display = value === null || value === undefined ? "" : value;
  return `<input name="${escapeHTML(name)}" type="number" step="0.01" value="${escapeHTML(display)}" ${attrs}>`;
}

export function dateInput(name, value = "", attrs = "") {
  return `<input name="${escapeHTML(name)}" type="date" value="${escapeHTML(value ?? "")}" ${attrs}>`;
}

export function selectInput(name, innerOptions, attrs = "") {
  return `<select name="${escapeHTML(name)}" ${attrs}>${innerOptions}</select>`;
}

export function textareaInput(name, value = "", attrs = "") {
  return `<textarea name="${escapeHTML(name)}" ${attrs}>${escapeHTML(value ?? "")}</textarea>`;
}

export function iconUse(id) {
  return `<svg aria-hidden="true"><use href="#${escapeHTML(id)}"></use></svg>`;
}
