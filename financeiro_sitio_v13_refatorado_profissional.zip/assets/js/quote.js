import { QUOTE_MIN_RETRY_MS } from "./config.js";

export const QUOTE_SOURCES = {
  noticias_es: {
    name: "Notícias Agrícolas - Conilon 7/8 ES",
    short: "Notícias Agrícolas",
    detail: "CCCV / Cooabriel / BCSP",
    url: "https://www.noticiasagricolas.com.br/cotacoes/cafe/cafe-conillon-disponivel-vitoria-es"
  },
  safras: {
    name: "Safras & Mercado - Conilon 7/8 Vitória/ES",
    short: "Safras & Mercado",
    detail: "Mercado físico Vitória/ES",
    url: "https://www.noticiasagricolas.com.br/cotacoes/mercado-fisico-safras-e-mercado"
  },
  cepea: {
    name: "CEPEA/ESALQ - Café Robusta",
    short: "CEPEA/ESALQ",
    detail: "Indicador Robusta",
    url: "https://www.noticiasagricolas.com.br/cotacoes/cafe/indicador-cepea-esalq-cafe-conillon"
  },
  cooabriel: {
    name: "Cooabriel - Conilon 7/8",
    short: "Cooabriel",
    detail: "Cotação do dia",
    url: "https://cooabriel.com.br/cotacao-do-dia"
  }
};

let lastAttempt = 0;

export function parseBRPrice(value) {
  let s = String(value || "")
    .replace(/R\$/gi, "")
    .replace(/\s/g, "")
    .trim();

  if (!s) return 0;

  if (s.includes(",")) {
    s = s.replace(/\./g, "").replace(",", ".");
    const n = Number(s);
    return Number.isFinite(n) ? n : 0;
  }

  if (/^\d{1,3}(?:\.\d{3})+$/.test(s)) {
    const n = Number(s.replace(/\./g, ""));
    return Number.isFinite(n) ? n : 0;
  }

  const n = Number(s);
  return Number.isFinite(n) ? n : 0;
}

function validPrice(value) {
  return Number.isFinite(value) && value >= 300 && value <= 5000;
}

function dateNear(text, index) {
  const chunk = text.slice(Math.max(0, index - 800), Math.min(text.length, index + 1400));
  const match =
    chunk.match(/Fechamento:\s*(\d{2}\/\d{2}\/\d{4})/i) ||
    chunk.match(/Atualizado em:\s*(\d{2}\/\d{2}\/\d{4})/i) ||
    chunk.match(/(\d{2}\/\d{2}\/\d{4})/);
  return match?.[1] || "";
}

function parseNoticiasES(text) {
  const t = String(text || "").replace(/\u00a0/g, " ");
  const idx = t.search(/Tipo\s*7\s*\/\s*8/i);
  if (idx < 0) return null;

  const chunk = t.slice(Math.max(0, idx - 500), idx + 900);
  const patterns = [
    /Tipo\s*7\s*\/\s*8[\s\S]{0,300}?\|\s*R?\$?\s*([0-9]{1,4}(?:\.[0-9]{3})*(?:,[0-9]{1,2})?)\s*\|/i,
    /Tipo\s*7\s*\/\s*8[\s\S]{0,300}?R\$\s*([0-9]{1,4}(?:\.[0-9]{3})*(?:,[0-9]{1,2})?)/i
  ];

  for (const pattern of patterns) {
    const m = chunk.match(pattern);
    if (!m) continue;
    const value = parseBRPrice(m[1]);
    if (validPrice(value)) return { value, sourceDate: dateNear(t, idx) };
  }
  return null;
}

function parseSafras(text) {
  const t = String(text || "").replace(/\u00a0/g, " ");
  const idx = t.search(/Cafe\s+Conilon\s+Tipo\s+7\s*\/\s*8\s+Vitoria-Es/i);
  if (idx < 0) return null;

  const chunk = t.slice(Math.max(0, idx - 250), idx + 700);
  const m = chunk.match(
    /Cafe\s+Conilon\s+Tipo\s+7\s*\/\s*8\s+Vitoria-Es[\s\S]{0,260}?\|\s*([0-9]{1,4}(?:\.[0-9]{3})*(?:,[0-9]{1,2})?)/i
  );
  if (!m) return null;
  const value = parseBRPrice(m[1]);
  return validPrice(value) ? { value, sourceDate: dateNear(t, idx) } : null;
}

function parseCepea(text) {
  const t = String(text || "").replace(/\u00a0/g, " ");
  const idx = t.search(/Indicador\s+Café\s+Robusta\s*-\s*Cepea\/Esalq/i);
  if (idx < 0) return null;

  const chunk = t.slice(idx, idx + 1300);
  const matches = [...chunk.matchAll(/([0-9]{1,4}(?:\.[0-9]{3})*,[0-9]{2})/g)];
  for (const m of matches) {
    const value = parseBRPrice(m[1]);
    if (validPrice(value)) return { value, sourceDate: dateNear(t, idx) };
  }
  return null;
}

function parseCooabriel(text) {
  const t = String(text || "").replace(/\u00a0/g, " ");
  const idx = t.search(/Conilon\s+7\s*\/\s*8/i);
  if (idx < 0) return null;

  const chunk = t.slice(Math.max(0, idx - 300), idx + 900);
  const m = chunk.match(
    /Conilon\s+7\s*\/\s*8[\s\S]{0,300}?R\$\s*([0-9]{1,4}(?:\.[0-9]{3})*(?:,[0-9]{1,2})?)/i
  );
  if (!m) return null;
  const value = parseBRPrice(m[1]);
  return validPrice(value) ? { value, sourceDate: dateNear(t, idx) } : null;
}

const PARSERS = {
  noticias_es: parseNoticiasES,
  safras: parseSafras,
  cepea: parseCepea,
  cooabriel: parseCooabriel
};

async function fetchText(url, timeoutMs = 24000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      cache: "no-store",
      signal: controller.signal,
      headers: { Accept: "text/plain,text/html,*/*" }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.text();
  } finally {
    clearTimeout(timer);
  }
}

async function sourceText(url) {
  const errors = [];
  for (const candidate of [`https://r.jina.ai/${url}`, url]) {
    try {
      return await fetchText(candidate);
    } catch (error) {
      errors.push(error);
    }
  }
  throw errors[0] || new Error("Fonte indisponível");
}

export async function consultQuoteSource(key) {
  const source = QUOTE_SOURCES[key];
  const parser = PARSERS[key];
  if (!source || !parser) throw new Error("Fonte de cotação inválida.");

  const text = await sourceText(source.url);
  const parsed = parser(text);
  if (!parsed) throw new Error(`Preço não encontrado em ${source.short}.`);

  return {
    price: parsed.value,
    sourceDate: parsed.sourceDate || "",
    sourceKey: key,
    sourceName: source.name,
    sourceShort: source.short,
    sourceDetail: source.detail,
    sourceUrl: source.url,
    updatedAt: new Date().toISOString()
  };
}

export async function fetchCoffeeQuote(preferred = "auto", { force = false } = {}) {
  const now = Date.now();
  if (!force && now - lastAttempt < QUOTE_MIN_RETRY_MS) {
    const error = new Error("Consulta recente; aguarde alguns minutos.");
    error.code = "QUOTE_THROTTLED";
    throw error;
  }
  lastAttempt = now;

  const baseOrder = ["noticias_es", "safras", "cepea", "cooabriel"];
  const order =
    preferred && preferred !== "auto" && baseOrder.includes(preferred)
      ? [preferred, ...baseOrder.filter((x) => x !== preferred)]
      : baseOrder;

  const errors = [];
  for (const key of order) {
    try {
      return await consultQuoteSource(key);
    } catch (error) {
      errors.push(`${key}: ${error.message}`);
    }
  }

  throw new Error(errors.join(" | ") || "Nenhuma fonte respondeu.");
}

export function regionalQuote(quote) {
  const price = Number(quote?.precoPainel || 0);
  const discount = Number(quote?.descontoRegional || 0);
  return price > 0 ? Math.max(0, price - discount) : 0;
}
