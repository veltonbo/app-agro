import { getState, mutate } from "./store.js";
import {
  accountsPayableSummary,
  getPendingAccounts,
  nomePessoa,
  nomeSafra,
  nomeTalhao
} from "./domain.js";
import {
  $, money, dateBR, dateISO, escapeHTML, normalizeText, sortByDateDesc, uid, toNumber
} from "./utils.js";
import {
  setModal, showToast, options, field, textInput, numberInput, dateInput, selectInput, textareaInput, iconUse
} from "./ui.js";

const filters = {
  search: "",
  type: "todos",
  status: "todos",
  safra: "todos",
  talhao: "todos",
  category: "todos",
  payable: "todos"
};

function syncLinkedStatus(draft, lancamento) {
  if (lancamento.apanhaId) {
    const source = draft.apanhas.find((x) => x.id === lancamento.apanhaId);
    if (source) source.status = lancamento.status;
  }
  if (lancamento.vendaId) {
    const source = draft.vendas.find((x) => x.id === lancamento.vendaId);
    if (source) source.status = lancamento.status;
  }
}

function lancamentoRow(item) {
  const state = getState();
  const pending = item.status !== "pago";
  const linked = Boolean(item.apanhaId || item.vendaId);
  const meta = [
    dateBR(item.data),
    item.categoria,
    item.talhaoId ? nomeTalhao(state, item.talhaoId) : "",
    item.safraId ? nomeSafra(state, item.safraId) : "",
    item.pessoaId ? nomePessoa(state, item.pessoaId) : "",
    pending && item.vencimento ? `Vence ${dateBR(item.vencimento)}` : "",
    linked ? "Vinculado" : ""
  ].filter(Boolean).join(" • ");

  return `<div class="list-row">
    <span class="row-icon ${item.tipo === "despesa" ? "red" : "blue"}">${iconUse(item.tipo === "despesa" ? "i-minus" : "i-plus")}</span>
    <div class="row-main">
      <strong>${escapeHTML(item.descricao || item.categoria || "Lançamento")}</strong>
      <small>${escapeHTML(meta)}</small>
    </div>
    <div class="row-value">
      <strong>${item.tipo === "despesa" ? "− " : "+ "}${money(item.valor)}</strong>
      <small>${pending ? (item.tipo === "despesa" ? "A pagar" : "A receber") : (item.tipo === "despesa" ? "Pago" : "Recebido")}</small>
      <div class="row-actions">
        <button class="icon-btn" type="button" data-action="toggle-launch-paid" data-id="${escapeHTML(item.id)}" title="Alterar status">${iconUse("i-check")}</button>
        <button class="icon-btn" type="button" data-action="edit-launch" data-id="${escapeHTML(item.id)}" title="Editar">${iconUse("i-edit")}</button>
        ${linked ? "" : `<button class="icon-btn" type="button" data-action="delete-launch" data-id="${escapeHTML(item.id)}" title="Excluir">${iconUse("i-trash")}</button>`}
      </div>
    </div>
  </div>`;
}

function accountRow(item) {
  const state = getState();
  const labels = {
    vencida: "Vencida",
    hoje: "Vence hoje",
    proxima: "Próximos 7 dias",
    futura: "Futura",
    "sem-vencimento": "Sem vencimento"
  };
  const badgeClass = item.situacao === "vencida" ? "red" : item.situacao === "hoje" || item.situacao === "proxima" ? "amber" : "";
  const meta = [
    item.categoria,
    item.pessoaId ? nomePessoa(state, item.pessoaId) : "",
    item.vencimento ? dateBR(item.vencimento) : "Sem vencimento"
  ].filter(Boolean).join(" • ");

  return `<div class="list-row">
    <span class="row-icon red">${iconUse("i-alert")}</span>
    <div class="row-main">
      <strong>${escapeHTML(item.descricao || item.categoria || "Conta")}</strong>
      <small>${escapeHTML(meta)}</small>
    </div>
    <div class="row-value">
      <strong>${money(item.valor)}</strong>
      <small><span class="badge ${badgeClass}">${escapeHTML(labels[item.situacao] || "Pendente")}</span></small>
      <div class="row-actions">
        <button class="icon-btn" type="button" data-action="toggle-launch-paid" data-id="${escapeHTML(item.id)}" title="Marcar pago">${iconUse("i-check")}</button>
        <button class="icon-btn" type="button" data-action="edit-launch" data-id="${escapeHTML(item.id)}" title="Editar">${iconUse("i-edit")}</button>
      </div>
    </div>
  </div>`;
}

export function renderFinance() {
  const state = getState();
  const summary = accountsPayableSummary(state);

  $("accountsSummary").innerHTML = `
    <article class="account-kpi"><small>Total a pagar</small><strong>${money(summary.total)}</strong></article>
    <article class="account-kpi red"><small>Vencido</small><strong>${money(summary.vencido)}</strong></article>
    <article class="account-kpi amber"><small>Próximos 7 dias</small><strong>${money(summary.proximos7)}</strong></article>
    <article class="account-kpi"><small>Quantidade</small><strong>${summary.quantidade}</strong></article>
  `;

  const payableItems = getPendingAccounts(state, "despesa").filter((x) => {
    if (filters.payable === "todos") return true;
    if (filters.payable === "vencidas") return x.situacao === "vencida";
    if (filters.payable === "hoje") return x.situacao === "hoje";
    if (filters.payable === "7dias") return ["hoje", "proxima"].includes(x.situacao);
    if (filters.payable === "sem-vencimento") return x.situacao === "sem-vencimento";
    return true;
  });

  $("payablesPanel").innerHTML = `
    <div class="section-head compact">
      <div><h3>Contas a pagar</h3><p>Esta lista é geral e não some ao trocar de safra.</p></div>
    </div>
    <div class="payable-tabs">
      ${[
        ["todos","Todas"],
        ["vencidas","Vencidas"],
        ["hoje","Hoje"],
        ["7dias","Próximos 7 dias"],
        ["sem-vencimento","Sem vencimento"]
      ].map(([value,label]) => `<button type="button" class="${filters.payable === value ? "active" : ""}" data-action="payable-filter" data-value="${value}">${label}</button>`).join("")}
    </div>
    <div class="list-card">${payableItems.length ? payableItems.map(accountRow).join("") : `<div class="empty"><strong>Nenhuma conta neste filtro.</strong>As pendências aparecerão aqui.</div>`}</div>
  `;

  populateFilters();

  let items = [...state.lancamentos];
  const q = normalizeText(filters.search);
  if (q) {
    items = items.filter((x) => normalizeText(`${x.descricao || ""} ${x.categoria || ""} ${x.obs || ""} ${nomePessoa(state, x.pessoaId)}`).includes(q));
  }
  if (filters.type !== "todos") items = items.filter((x) => x.tipo === filters.type);
  if (filters.status !== "todos") items = items.filter((x) => (filters.status === "pago" ? x.status === "pago" : x.status !== "pago"));
  if (filters.safra !== "todos") items = items.filter((x) => x.safraId === filters.safra);
  if (filters.talhao !== "todos") items = items.filter((x) => x.talhaoId === filters.talhao);
  if (filters.category !== "todos") items = items.filter((x) => x.categoria === filters.category);
  items.sort((a,b) => sortByDateDesc(a,b,"data"));

  $("financeCount").textContent = `${items.length} registro${items.length === 1 ? "" : "s"}`;
  $("financeList").innerHTML = items.length
    ? items.map(lancamentoRow).join("")
    : `<div class="empty"><strong>Nenhum lançamento encontrado.</strong>Ajuste os filtros ou crie um novo lançamento.</div>`;
}

function populateFilters() {
  const state = getState();

  const setSelect = (id, value, html) => {
    const el = $(id);
    if (!el) return;
    const current = value;
    el.innerHTML = html;
    el.value = [...el.options].some((o) => o.value === current) ? current : "todos";
  };

  setSelect("financeSafra", filters.safra,
    `<option value="todos">Todas as safras</option>` +
    options(state.safras, "", { getValue: (x) => x.id, getLabel: (x) => x.nome })
  );
  filters.safra = $("financeSafra").value;

  setSelect("financeTalhao", filters.talhao,
    `<option value="todos">Todos os talhões</option>` +
    options(state.talhoes, "", { getValue: (x) => x.id, getLabel: (x) => x.nome })
  );
  filters.talhao = $("financeTalhao").value;

  const cats = [...new Set([...state.categorias.receita, ...state.categorias.despesa])].sort((a,b)=>a.localeCompare(b,"pt-BR"));
  setSelect("financeCategory", filters.category,
    `<option value="todos">Todas as categorias</option>` +
    cats.map((x)=>`<option value="${escapeHTML(x)}">${escapeHTML(x)}</option>`).join("")
  );
  filters.category = $("financeCategory").value;

  $("financeSearch").value = filters.search;
  $("financeType").value = filters.type;
  $("financeStatus").value = filters.status;
}

export function bindFinanceFilters(render) {
  const map = [
    ["financeSearch", "search", "input"],
    ["financeType", "type", "change"],
    ["financeStatus", "status", "change"],
    ["financeSafra", "safra", "change"],
    ["financeTalhao", "talhao", "change"],
    ["financeCategory", "category", "change"]
  ];
  for (const [id,key,event] of map) {
    $(id)?.addEventListener(event, (e) => {
      filters[key] = e.target.value;
      render();
    });
  }
}

export function clearFinanceFilters() {
  Object.assign(filters, {
    search: "",
    type: "todos",
    status: "todos",
    safra: "todos",
    talhao: "todos",
    category: "todos"
  });
  renderFinance();
}

export function setPayableFilter(value) {
  filters.payable = value;
  renderFinance();
}

export function openLancamentoForm({ type = "receita", id = "" } = {}) {
  const state = getState();
  const item = id ? state.lancamentos.find((x) => x.id === id) : null;
  if (id && !item) return;

  const linked = Boolean(item?.apanhaId || item?.vendaId);
  const currentType = item?.tipo || type;
  const currentSafra = item?.safraId || state.safraAtivaId || "";
  const categories = currentType === "receita" ? state.categorias.receita : state.categorias.despesa;

  const body = `
    ${linked ? `<div class="form-hint" style="margin-bottom:10px">Este lançamento é vinculado à ${item.apanhaId ? "colheita de um colhedor" : "venda de café"}. Valor, tipo e descrição são controlados pelo registro de origem.</div>` : ""}
    <div class="form-grid">
      ${field("Tipo", selectInput("tipo", `
        <option value="receita"${currentType === "receita" ? " selected" : ""}>Receita</option>
        <option value="despesa"${currentType === "despesa" ? " selected" : ""}>Despesa</option>
      `, linked ? "disabled" : ""), {})}
      ${field("Data", dateInput("data", item?.data || dateISO(), linked ? "disabled" : ""))}
      ${field("Valor", numberInput("valor", item?.valor ?? "", `min="0" required ${linked ? "readonly" : ""}`))}
      ${field("Status", selectInput("status", `
        <option value="pago"${item?.status === "pago" || (!item && true) ? " selected" : ""}>${currentType === "receita" ? "Recebido" : "Pago"}</option>
        <option value="pendente"${item?.status !== "pago" && item ? " selected" : ""}>${currentType === "receita" ? "A receber" : "A pagar"}</option>
      `))}
      ${field("Vencimento", dateInput("vencimento", item?.vencimento || ""))}
      ${field("Categoria", selectInput("categoria", options(categories.map((nome)=>({nome})), item?.categoria || categories[0] || "", {getValue:(x)=>x.nome,getLabel:(x)=>x.nome}), linked ? "disabled" : ""))}
      ${field("Safra", selectInput("safraId", options(state.safras, currentSafra, {includeEmpty:true,emptyLabel:"Sem safra"}), linked ? "disabled" : ""))}
      ${field("Talhão", selectInput("talhaoId", options(state.talhoes, item?.talhaoId || "", {includeEmpty:true,emptyLabel:"Sem talhão"}), linked ? "disabled" : ""))}
      ${field("Fornecedor / comprador", selectInput("pessoaId", options(state.pessoas, item?.pessoaId || "", {includeEmpty:true,emptyLabel:"Não informado"})))}
      ${field("Parcela", textInput("parcela", item?.parcela || "", `placeholder="Ex.: 2/4"`))}
      ${field("Documento / nota", textInput("documento", item?.documento || "", `placeholder="NF, boleto, referência..."`))}
      ${field("Descrição", textInput("descricao", item?.descricao || "", `required ${linked ? "readonly" : ""}`), {full:true})}
      ${field("Observação", textareaInput("obs", item?.obs || ""), {full:true})}
    </div>
  `;

  setModal({
    eyebrow: currentType === "receita" ? "RECEITA" : "DESPESA",
    title: item ? "Editar lançamento" : "Novo lançamento",
    body,
    submitLabel: "Salvar lançamento",
    onSubmit: async (formData) => {
      const valor = linked ? toNumber(item.valor) : toNumber(formData.get("valor"));
      const descricao = linked ? item.descricao : String(formData.get("descricao") || "").trim();
      if (valor <= 0) throw new Error("Informe um valor maior que zero.");
      if (!descricao) throw new Error("Informe a descrição.");

      mutate((draft) => {
        const current = item ? draft.lancamentos.find((x) => x.id === item.id) : null;
        const next = {
          id: current?.id || uid("lan"),
          tipo: linked ? current.tipo : String(formData.get("tipo") || currentType),
          data: linked ? current.data : String(formData.get("data") || dateISO()),
          valor: linked ? toNumber(current.valor) : valor,
          status: String(formData.get("status") || "pago"),
          vencimento: String(formData.get("vencimento") || ""),
          categoria: linked ? current.categoria : String(formData.get("categoria") || ""),
          safraId: linked ? (current.safraId || "") : String(formData.get("safraId") || ""),
          talhaoId: linked ? (current.talhaoId || "") : String(formData.get("talhaoId") || ""),
          pessoaId: String(formData.get("pessoaId") || ""),
          parcela: String(formData.get("parcela") || "").trim(),
          documento: String(formData.get("documento") || "").trim(),
          descricao: linked ? current.descricao : descricao,
          obs: String(formData.get("obs") || "").trim(),
          ...(current?.apanhaId ? { apanhaId: current.apanhaId } : {}),
          ...(current?.vendaId ? { vendaId: current.vendaId } : {})
        };

        if (current) {
          Object.assign(current, next);
          syncLinkedStatus(draft, current);
        } else {
          draft.lancamentos.push(next);
        }
      });
      showToast("Lançamento salvo.");
    }
  });

  const tipoSelect = document.querySelector('#modalBody select[name="tipo"]');
  if (tipoSelect && !linked) {
    tipoSelect.addEventListener("change", () => {
      const form = new FormData($("modalForm"));
      const partial = Object.fromEntries(form.entries());
      // Reabre mantendo os campos principais e mudando as categorias.
      openLancamentoForm({ type: tipoSelect.value });
      const formEl = $("modalForm");
      for (const [key,value] of Object.entries(partial)) {
        const input = formEl.elements.namedItem(key);
        if (input && key !== "tipo" && key !== "categoria") input.value = value;
      }
    });
  }
}

export function toggleLaunchPaid(id) {
  mutate((draft) => {
    const item = draft.lancamentos.find((x) => x.id === id);
    if (!item) return;
    item.status = item.status === "pago" ? "pendente" : "pago";
    syncLinkedStatus(draft, item);
  });
  showToast("Status atualizado.");
}

export function deleteLaunch(id) {
  const state = getState();
  const item = state.lancamentos.find((x) => x.id === id);
  if (!item) return;
  if (item.apanhaId || item.vendaId) {
    showToast("Este lançamento é vinculado e deve ser alterado no registro de origem.");
    return;
  }
  if (!confirm("Excluir este lançamento?")) return;
  mutate((draft) => {
    draft.lancamentos = draft.lancamentos.filter((x) => x.id !== id);
  });
  showToast("Lançamento excluído.");
}

export function financeFilters() {
  return filters;
}
