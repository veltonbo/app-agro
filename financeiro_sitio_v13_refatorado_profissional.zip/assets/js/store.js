import {
  DEFAULT_REVENUE_CATEGORIES,
  DEFAULT_EXPENSE_CATEGORIES,
  QUOTE_DEFAULT_DISCOUNT
} from "./config.js";
import { clone, uniqueStrings } from "./utils.js";

export function emptyState() {
  return {
    lancamentos: [],
    talhoes: [],
    colheitas: [],
    vendas: [],
    trabalhadores: [],
    apanhas: [],
    lotes: [],
    safras: [],
    safraAtivaId: "",
    categorias: {
      receita: [...DEFAULT_REVENUE_CATEGORIES],
      despesa: [...DEFAULT_EXPENSE_CATEGORIES]
    },
    pessoas: [],
    cotacaoCafe: {
      descontoRegional: QUOTE_DEFAULT_DISCOUNT,
      autoAtualizar: true,
      precoPainel: 0,
      dataFonte: "",
      atualizadoEm: "",
      origem: "",
      fontePreferida: "auto",
      fonteAtual: "",
      urlFonteAtual: "",
      detalheFonte: ""
    },
    analisesSolo: []
  };
}

function normalizeSafras(raw) {
  const safras = Array.isArray(raw?.safras)
    ? raw.safras.filter(Boolean).map((s) => ({
        id: String(s.id || ""),
        nome: String(s.nome || "Safra").trim() || "Safra",
        ano: Number(s.ano) || null,
        fechada: s.fechada === true
      })).filter((s) => s.id)
    : [];

  let safraAtivaId = String(raw?.safraAtivaId || "");
  if (!safras.some((s) => s.id === safraAtivaId && !s.fechada)) {
    const aberta = safras.find((s) => !s.fechada);
    safraAtivaId = aberta?.id || "";
  }

  return { safras, safraAtivaId };
}

function normalizeCategories(raw) {
  const receita = uniqueStrings([
    ...DEFAULT_REVENUE_CATEGORIES,
    ...(raw?.categorias?.receita || []),
    ...(Array.isArray(raw?.lancamentos)
      ? raw.lancamentos.filter((x) => x?.tipo === "receita").map((x) => x.categoria)
      : [])
  ]);

  const despesa = uniqueStrings([
    ...DEFAULT_EXPENSE_CATEGORIES,
    ...(raw?.categorias?.despesa || []),
    ...(Array.isArray(raw?.lancamentos)
      ? raw.lancamentos.filter((x) => x?.tipo === "despesa").map((x) => x.categoria)
      : [])
  ]);

  return { receita, despesa };
}

function normalizeQuote(raw) {
  const c = raw?.cotacaoCafe || {};
  return {
    descontoRegional: Number.isFinite(Number(c.descontoRegional))
      ? Math.max(0, Number(c.descontoRegional))
      : QUOTE_DEFAULT_DISCOUNT,
    autoAtualizar: c.autoAtualizar !== false,
    precoPainel: Number.isFinite(Number(c.precoPainel)) ? Math.max(0, Number(c.precoPainel)) : 0,
    dataFonte: String(c.dataFonte || ""),
    atualizadoEm: String(c.atualizadoEm || ""),
    origem: String(c.origem || ""),
    fontePreferida: ["auto", "noticias_es", "safras", "cepea", "cooabriel"].includes(c.fontePreferida)
      ? c.fontePreferida
      : "auto",
    fonteAtual: String(c.fonteAtual || ""),
    urlFonteAtual: String(c.urlFonteAtual || ""),
    detalheFonte: String(c.detalheFonte || "")
  };
}

function normalizeList(value) {
  return Array.isArray(value) ? value.filter(Boolean).map((x) => ({ ...x })) : [];
}

export function normalizeState(raw = {}) {
  const base = emptyState();
  const { safras, safraAtivaId } = normalizeSafras(raw);

  const state = {
    ...base,
    lancamentos: normalizeList(raw.lancamentos),
    talhoes: normalizeList(raw.talhoes),
    colheitas: normalizeList(raw.colheitas),
    vendas: normalizeList(raw.vendas),
    trabalhadores: normalizeList(raw.trabalhadores),
    apanhas: normalizeList(raw.apanhas),
    lotes: normalizeList(raw.lotes),
    safras,
    safraAtivaId,
    categorias: normalizeCategories(raw),
    pessoas: normalizeList(raw.pessoas),
    cotacaoCafe: normalizeQuote(raw),
    analisesSolo: normalizeList(raw.analisesSolo)
  };

  // Compatibilidade: registros antigos que não têm safra permanecem válidos,
  // mas, se já houver uma safra ativa, ela é usada como vínculo padrão.
  const fallbackSafra = state.safraAtivaId;
  if (fallbackSafra) {
    for (const listName of ["lancamentos", "colheitas", "vendas", "apanhas", "lotes"]) {
      state[listName] = state[listName].map((item) => ({
        ...item,
        safraId: item.safraId || fallbackSafra
      }));
    }
  }

  // Migração dos lotes antigos, que guardavam apenas apanhaIds.
  state.lotes = state.lotes.map((lote) => {
    if (Array.isArray(lote.alocacoes)) return lote;
    const apanhaIds = Array.isArray(lote.apanhaIds) ? lote.apanhaIds : [];
    const alocacoes = apanhaIds.map((apanhaId) => {
      const apanha = state.apanhas.find((a) => a.id === apanhaId);
      return {
        apanhaId,
        latoes: Number(apanha?.latoes || 0)
      };
    }).filter((x) => x.apanhaId && x.latoes > 0);

    const copy = { ...lote, alocacoes };
    delete copy.apanhaIds;
    return copy;
  });

  return state;
}

let state = normalizeState();
const listeners = new Set();

export function getState() {
  return state;
}

export function getStateClone() {
  return clone(state);
}

export function replaceState(raw, source = "remote") {
  state = normalizeState(raw);
  emit(source);
  return state;
}

export function mutate(mutator, source = "local") {
  const draft = clone(state);
  mutator(draft);
  state = normalizeState(draft);
  emit(source);
  return state;
}

export function resetState(source = "system") {
  state = normalizeState(emptyState());
  emit(source);
}

export function subscribe(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function emit(source) {
  for (const listener of listeners) {
    try {
      listener(state, source);
    } catch (error) {
      console.error("Falha em listener do estado:", error);
    }
  }
}
