import { getState } from "./store.js";
import {
  expensesByCategory,
  filterRecords,
  nomeSafra,
  nomeTalhao,
  nomeTrabalhador,
  talhaoPerformance
} from "./domain.js";
import {
  $, money, numberBR, dateBR, dateISO, escapeHTML, csvCell, downloadText, toNumber
} from "./utils.js";

const filters = {
  start: "",
  end: "",
  safraId: "todos",
  talhaoId: "todos"
};

function filteredStateParts(state) {
  const base = {
    start: filters.start,
    end: filters.end,
    safraId: filters.safraId,
    talhaoId: filters.talhaoId
  };
  return {
    lancamentos: filterRecords(state.lancamentos, base),
    colheitas: filterRecords(state.colheitas, base),
    vendas: filterRecords(state.vendas, base),
    apanhas: filterRecords(state.apanhas, base)
  };
}

function calcKpis(parts) {
  const receitas = parts.lancamentos
    .filter((x) => x.tipo === "receita" && x.status === "pago")
    .reduce((s, x) => s + toNumber(x.valor), 0);
  const despesas = parts.lancamentos
    .filter((x) => x.tipo === "despesa" && x.status === "pago")
    .reduce((s, x) => s + toNumber(x.valor), 0);
  const produzido = parts.colheitas.reduce((s, x) => s + toNumber(x.sacas), 0);
  const vendido = parts.vendas.reduce((s, x) => s + toNumber(x.sacas), 0);
  const valorVendas = parts.vendas.reduce((s, x) => s + toNumber(x.total), 0);
  const custoSaca = produzido > 0 ? despesas / produzido : 0;
  const precoMedio = vendido > 0 ? valorVendas / vendido : 0;
  return {
    receitas,
    despesas,
    resultado: receitas - despesas,
    produzido,
    vendido,
    estoque: Math.max(0, produzido - vendido),
    custoSaca,
    precoMedio,
    margemSaca: precoMedio - custoSaca
  };
}

export function renderReports() {
  const state = getState();
  populateReportFilters(state);
  const parts = filteredStateParts(state);
  const kpi = calcKpis(parts);

  $("reportKpis").innerHTML = [
    ["Receitas", money(kpi.receitas)],
    ["Despesas", money(kpi.despesas)],
    ["Resultado", money(kpi.resultado)],
    ["Produzido", `${numberBR(kpi.produzido)} sc`],
    ["Custo / saca", money(kpi.custoSaca)],
    ["Margem / saca", money(kpi.margemSaca)]
  ].map(([label,value]) => `<article class="report-kpi"><small>${escapeHTML(label)}</small><strong>${escapeHTML(value)}</strong></article>`).join("");

  renderCategoryReport(parts.lancamentos);
  renderTalhaoReport(state);
  renderWorkerReport(state, parts.apanhas);
  renderSoilReport(state);

  const meta = [
    filters.start ? `De ${dateBR(filters.start)}` : "",
    filters.end ? `Até ${dateBR(filters.end)}` : "",
    filters.safraId !== "todos" ? nomeSafra(state, filters.safraId) : "Todas as safras",
    filters.talhaoId !== "todos" ? nomeTalhao(state, filters.talhaoId) : "Todos os talhões"
  ].filter(Boolean).join(" • ");
  $("printReportMeta").textContent = meta;
}

function populateReportFilters(state) {
  const safra = $("reportSafra");
  const talhao = $("reportTalhao");

  const safraValue = filters.safraId;
  safra.innerHTML = `<option value="todos">Todas as safras</option>` +
    state.safras.map((x) => `<option value="${escapeHTML(x.id)}">${escapeHTML(x.nome)}</option>`).join("");
  safra.value = [...safra.options].some((o) => o.value === safraValue) ? safraValue : "todos";
  filters.safraId = safra.value;

  const talhaoValue = filters.talhaoId;
  talhao.innerHTML = `<option value="todos">Todos os talhões</option>` +
    state.talhoes.map((x) => `<option value="${escapeHTML(x.id)}">${escapeHTML(x.nome)}</option>`).join("");
  talhao.value = [...talhao.options].some((o) => o.value === talhaoValue) ? talhaoValue : "todos";
  filters.talhaoId = talhao.value;

  $("reportStart").value = filters.start;
  $("reportEnd").value = filters.end;
}

function renderCategoryReport(lancamentos) {
  const rows = expensesByCategory(lancamentos);
  const total = rows.reduce((s, x) => s + x.valor, 0);
  $("reportCategories").innerHTML = rows.length
    ? rows.map((x) => {
        const pct = total > 0 ? (x.valor / total) * 100 : 0;
        return `<div class="category-bar">
          <div>
            <div style="display:flex;justify-content:space-between;gap:8px"><span class="name">${escapeHTML(x.categoria)}</span><span class="value">${money(x.valor)}</span></div>
            <div class="track"><i style="width:${Math.min(100,pct).toFixed(2)}%"></i></div>
          </div>
          <span class="value">${numberBR(pct,1)}%</span>
        </div>`;
      }).join("")
    : `<div class="empty">Nenhuma despesa paga no filtro.</div>`;
}

function renderTalhaoReport(state) {
  const rows = talhaoPerformance(state, {
    safraId: filters.safraId,
    start: filters.start,
    end: filters.end
  }).filter((row) => filters.talhaoId === "todos" || row.talhao.id === filters.talhaoId);

  $("reportTalhoes").innerHTML = rows.length
    ? rows.map((row) => `<tr>
      <td>${escapeHTML(row.talhao.nome)}</td>
      <td>${numberBR(row.produzido)} sc</td>
      <td>${money(row.despesas)}</td>
      <td>${money(row.receitas)}</td>
      <td>${money(row.resultado)}</td>
      <td>${money(row.custoSaca)}</td>
    </tr>`).join("")
    : `<tr><td colspan="6">Nenhum talhão cadastrado.</td></tr>`;
}

function renderWorkerReport(state, apanhas) {
  const groups = new Map();
  for (const item of apanhas) {
    if (!groups.has(item.trabalhadorId)) groups.set(item.trabalhadorId, { latoes:0,total:0,pago:0,pendente:0 });
    const row = groups.get(item.trabalhadorId);
    const total = toNumber(item.latoes) * toNumber(item.valorLatao);
    row.latoes += toNumber(item.latoes);
    row.total += total;
    if (item.status === "pago") row.pago += total;
    else row.pendente += total;
  }
  const rows = [...groups.entries()].sort((a,b)=>nomeTrabalhador(state,a[0]).localeCompare(nomeTrabalhador(state,b[0]),"pt-BR"));
  $("reportWorkers").innerHTML = rows.length
    ? rows.map(([id,row]) => `<tr>
      <td>${escapeHTML(nomeTrabalhador(state,id))}</td>
      <td>${numberBR(row.latoes)}</td>
      <td>${money(row.total)}</td>
      <td>${money(row.pago)}</td>
      <td>${money(row.pendente)}</td>
    </tr>`).join("")
    : `<tr><td colspan="5">Nenhum registro de colheita no filtro.</td></tr>`;
}

function soilValue(value) {
  if (value === null || value === undefined || value === "") return "—";
  return numberBR(value);
}

function renderSoilReport(state) {
  const list = state.analisesSolo.filter((x) => {
    const okDate = (!filters.start || !x.data || x.data >= filters.start) && (!filters.end || !x.data || x.data <= filters.end);
    const okTalhao = filters.talhaoId === "todos" || x.talhaoId === filters.talhaoId;
    return okDate && okTalhao;
  });

  const latest = new Map();
  for (const item of list) {
    const current = latest.get(item.talhaoId);
    if (!current || String(item.data || "") > String(current.data || "")) latest.set(item.talhaoId, item);
  }

  $("reportSoil").innerHTML = latest.size
    ? [...latest.values()].sort((a,b)=>nomeTalhao(state,a.talhaoId).localeCompare(nomeTalhao(state,b.talhaoId),"pt-BR")).map((a) => `<tr>
      <td>${escapeHTML(nomeTalhao(state,a.talhaoId))}</td>
      <td>${dateBR(a.data)}</td>
      <td>${escapeHTML(a.profundidade || "—")}</td>
      <td>${soilValue(a.ph)}</td>
      <td>${soilValue(a.p)}</td>
      <td>${soilValue(a.k)}</td>
      <td>${soilValue(a.ca)}</td>
      <td>${soilValue(a.mg)}</td>
      <td>${soilValue(a.v)}</td>
    </tr>`).join("")
    : `<tr><td colspan="9">Nenhuma análise de solo no filtro.</td></tr>`;
}

export function bindReportFilters(render) {
  const bindings = [
    ["reportStart","start","change"],
    ["reportEnd","end","change"],
    ["reportSafra","safraId","change"],
    ["reportTalhao","talhaoId","change"]
  ];
  for (const [id,key,event] of bindings) {
    $(id)?.addEventListener(event,(e)=>{filters[key]=e.target.value;render()});
  }
}

export function clearReportFilters() {
  Object.assign(filters,{start:"",end:"",safraId:"todos",talhaoId:"todos"});
  renderReports();
}

export function exportReportCSV() {
  const state = getState();
  const parts = filteredStateParts(state);
  const rows = [
    ["SEÇÃO","Data","Safra","Talhão","Tipo/Categoria","Descrição/Comprador","Status","Quantidade","Valor"]
  ];

  for (const x of parts.lancamentos) {
    rows.push([
      "Financeiro",
      x.data,
      x.safraId ? nomeSafra(state,x.safraId) : "",
      x.talhaoId ? nomeTalhao(state,x.talhaoId) : "",
      `${x.tipo} / ${x.categoria || ""}`,
      x.descricao || "",
      x.status || "",
      "",
      x.valor || 0
    ]);
  }
  for (const x of parts.colheitas) {
    rows.push([
      "Produção",
      x.data,
      x.safraId ? nomeSafra(state,x.safraId) : "",
      x.talhaoId ? nomeTalhao(state,x.talhaoId) : "",
      "Sacas produzidas",
      x.obs || "",
      "",
      x.sacas || 0,
      ""
    ]);
  }
  for (const x of parts.vendas) {
    rows.push([
      "Venda",
      x.data,
      x.safraId ? nomeSafra(state,x.safraId) : "",
      x.talhaoId ? nomeTalhao(state,x.talhaoId) : "",
      "Venda de café",
      x.comprador || "",
      x.status || "",
      x.sacas || 0,
      x.total || 0
    ]);
  }

  const csv = "\uFEFF" + rows.map((r) => r.map(csvCell).join(";")).join("\n");
  downloadText(`relatorio-financeiro-sitio-${dateISO()}.csv`, csv, "text/csv;charset=utf-8");
}

export function reportFilters() {
  return { ...filters };
}
