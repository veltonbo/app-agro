import { APP_VERSION, QUOTE_REFRESH_MS } from "./config.js";
import { getState, mutate, subscribe } from "./store.js";
import { $, money, dateTimeBR } from "./utils.js";
import { setPage, closeModal, showToast } from "./ui.js";
import {
  startFirebase, login, register, logout, authErrorMessage, cloudSync
} from "./firebase.js";
import { renderDashboard } from "./dashboard.js";
import {
  bindFinanceFilters, clearFinanceFilters, deleteLaunch, openLancamentoForm,
  renderFinance, setPayableFilter, toggleLaunchPaid
} from "./finance.js";
import {
  deleteApanha, deleteLot, deleteProduction, deleteSale, openApanhaForm,
  openCloseLot, openLotForm, openProductionForm, openSaleForm, openWorkerAccount,
  openWorkerForm, renderHarvest, toggleApanhaPaid
} from "./harvest.js";
import {
  downloadBackup, importBackupFile, openCategoriesManager, openPeopleManager,
  openQuoteSettings, openSafraManager, openSoilManager, openTalhaoManager,
  openWorkersManager, renderProfile
} from "./profile.js";
import {
  bindReportFilters, clearReportFilters, exportReportCSV, renderReports
} from "./reports.js";
import { fetchCoffeeQuote, regionalQuote } from "./quote.js";

let currentUser = null;
let syncStatus = "Conectando...";
let currentPage = "resumo";
let quoteTimer = null;
let quoteBusy = false;

function setSync({ text, kind = "normal" }) {
  syncStatus = text;
  const chip = $("syncChip");
  chip.className = `sync-chip ${kind === "normal" ? "" : kind}`;
  chip.querySelector("span").textContent = text;
  $("heroSync").textContent = text;
}

function setUser(user) {
  currentUser = user;
  const loggedIn = Boolean(user);
  $("authScreen").classList.toggle("hidden", loggedIn);
  $("appShell").classList.toggle("hidden", !loggedIn);

  if (!loggedIn) {
    clearInterval(quoteTimer);
    quoteTimer = null;
    closeModal();
    return;
  }

  const email = user.email || "Usuário";
  $("userEmail").textContent = email;
  $("userAvatar").textContent = email.charAt(0).toUpperCase();
  $("profileEmail").textContent = email;
  $("profileAvatar").textContent = email.charAt(0).toUpperCase();

  scheduleQuote();
  setTimeout(() => refreshQuote(false), 1000);
}

function renderAll() {
  if (!currentUser) return;
  renderDashboard(syncStatus);
  renderFinance();
  renderHarvest();
  renderReports();
  renderProfile(currentUser);
}

function switchPage(page) {
  currentPage = page;
  setPage(page);
  if (page === "financeiro") renderFinance();
  if (page === "colheita") renderHarvest();
  if (page === "relatorios") renderReports();
  if (page === "perfil") renderProfile(currentUser);
}

async function refreshQuote(force = false) {
  if (!currentUser || quoteBusy) return;
  quoteBusy = true;

  const state = getState();
  const previous = state.cotacaoCafe;
  if (force) showToast("Atualizando cotação...");

  try {
    const result = await fetchCoffeeQuote(previous.fontePreferida || "auto", { force });
    mutate((draft) => {
      draft.cotacaoCafe.precoPainel = result.price;
      draft.cotacaoCafe.dataFonte = result.sourceDate || "";
      draft.cotacaoCafe.atualizadoEm = result.updatedAt;
      draft.cotacaoCafe.origem = "automatico";
      draft.cotacaoCafe.fonteAtual = result.sourceName;
      draft.cotacaoCafe.urlFonteAtual = result.sourceUrl;
      draft.cotacaoCafe.detalheFonte = result.sourceDetail;
      draft.cotacaoCafe.autoAtualizar = true;
    });

    if (force) {
      const q = getState().cotacaoCafe;
      showToast(`Cotação atualizada • Região: ${money(regionalQuote(q))}`);
    }
  } catch (error) {
    if (force && error?.code !== "QUOTE_THROTTLED") {
      showToast("Não consegui atualizar agora. A última cotação válida foi mantida.");
    }
    console.warn("Cotação não atualizada:", error);
  } finally {
    quoteBusy = false;
  }
}

function scheduleQuote() {
  clearInterval(quoteTimer);
  quoteTimer = setInterval(() => refreshQuote(false), QUOTE_REFRESH_MS);
}

function requireActiveSafra(action) {
  if (getState().safraAtivaId) {
    action();
    return;
  }
  showToast("Cadastre uma safra ativa primeiro.");
  openSafraManager();
}

function handleAction(action, el) {
  const id = el.dataset.id || "";
  const value = el.dataset.value || "";

  switch (action) {
    case "close-modal":
      closeModal();
      return true;
    case "register":
      registerAccount();
      return true;
    case "logout":
      logout().catch((error) => showToast(authErrorMessage(error)));
      return true;
    case "open-profile":
      switchPage("perfil");
      return true;
    case "go-finance":
      switchPage("financeiro");
      return true;
    case "show-payables":
      switchPage("financeiro");
      document.getElementById("payablesPanel")?.scrollIntoView({ behavior: "smooth", block: "start" });
      return true;
    case "new-income":
      openLancamentoForm({ type: "receita" });
      return true;
    case "new-expense":
      openLancamentoForm({ type: "despesa" });
      return true;
    case "edit-launch":
      openLancamentoForm({ id });
      return true;
    case "delete-launch":
      deleteLaunch(id);
      return true;
    case "toggle-launch-paid":
      toggleLaunchPaid(id);
      return true;
    case "payable-filter":
      setPayableFilter(value);
      return true;
    case "clear-finance-filters":
      clearFinanceFilters();
      return true;
    case "new-worker":
      openWorkerForm();
      return true;
    case "edit-worker":
      openWorkerForm(id);
      return true;
    case "worker-account":
      openWorkerAccount(id);
      return true;
    case "new-harvest":
      requireActiveSafra(() => openApanhaForm());
      return true;
    case "edit-harvest":
      openApanhaForm(id);
      return true;
    case "delete-harvest":
      deleteApanha(id);
      return true;
    case "toggle-harvest-paid":
      toggleApanhaPaid(id);
      return true;
    case "new-lot":
      requireActiveSafra(() => openLotForm());
      return true;
    case "edit-lot":
      openLotForm(id);
      return true;
    case "close-lot":
      openCloseLot(id);
      return true;
    case "delete-lot":
      deleteLot(id);
      return true;
    case "new-production":
      requireActiveSafra(() => openProductionForm());
      return true;
    case "edit-production":
      openProductionForm(id);
      return true;
    case "delete-production":
      deleteProduction(id);
      return true;
    case "new-sale": {
      requireActiveSafra(() => openSaleForm());
      return true;
    }
    case "edit-sale":
      openSaleForm(id);
      return true;
    case "delete-sale":
      deleteSale(id);
      return true;
    case "manage-workers":
      openWorkersManager();
      return true;
    case "manage-safras":
      openSafraManager();
      return true;
    case "manage-talhao":
      openTalhaoManager();
      return true;
    case "manage-categories":
      openCategoriesManager();
      return true;
    case "manage-people":
      openPeopleManager();
      return true;
    case "manage-soil":
      openSoilManager();
      return true;
    case "quote-settings":
      openQuoteSettings(refreshQuote);
      return true;
    case "sale-with-quote": {
      const value = regionalQuote(getState().cotacaoCafe);
      if (value <= 0) {
        showToast("Ainda não há cotação disponível. Atualizando...");
        refreshQuote(true);
        return true;
      }
      requireActiveSafra(() => openSaleForm("", value));
      return true;
    }
    case "refresh-quote":
      refreshQuote(true);
      return true;
    case "export-csv":
      exportReportCSV();
      showToast("CSV gerado.");
      return true;
    case "print-report":
      renderReports();
      window.print();
      return true;
    case "clear-report-filters":
      clearReportFilters();
      return true;
    case "download-backup":
      downloadBackup();
      return true;
    case "import-backup":
      $("backupFile").click();
      return true;
    default:
      return false;
  }
}

async function registerAccount() {
  const email = $("authEmail").value.trim();
  const password = $("authPassword").value;
  const errorBox = $("authError");
  errorBox.classList.add("hidden");

  if (!email || password.length < 6) {
    errorBox.textContent = "Informe um e-mail válido e uma senha com pelo menos 6 caracteres.";
    errorBox.classList.remove("hidden");
    return;
  }

  try {
    await register(email, password);
  } catch (error) {
    errorBox.textContent = authErrorMessage(error);
    errorBox.classList.remove("hidden");
  }
}

function bindStaticEvents() {
  $("authForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const email = $("authEmail").value.trim();
    const password = $("authPassword").value;
    const errorBox = $("authError");
    errorBox.classList.add("hidden");

    try {
      await login(email, password);
    } catch (error) {
      errorBox.textContent = authErrorMessage(error);
      errorBox.classList.remove("hidden");
    }
  });

  document.addEventListener("click", (event) => {
    const nav = event.target.closest("[data-page]");
    if (nav) {
      switchPage(nav.dataset.page);
      return;
    }

    const scroll = event.target.closest("[data-scroll]");
    if (scroll) {
      document.getElementById(scroll.dataset.scroll)?.scrollIntoView({ behavior: "smooth", block: "start" });
      return;
    }

    const actionEl = event.target.closest("[data-action]");
    if (actionEl) handleAction(actionEl.dataset.action, actionEl);
  });

  $("dashSafraSelect").addEventListener("change", (event) => {
    const id = event.target.value;
    if (!id) return;
    mutate((draft) => {
      const safra = draft.safras.find((x) => x.id === id);
      if (safra && !safra.fechada) draft.safraAtivaId = id;
    });
    showToast("Safra ativa alterada.");
  });

  $("backupFile").addEventListener("change", async (event) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    try {
      await importBackupFile(file);
    } catch (error) {
      showToast(error?.message || "Não foi possível importar o backup.");
    }
  });

  window.addEventListener("online", () => currentUser && setTimeout(() => refreshQuote(false), 600));
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && currentUser) refreshQuote(false);
  });

  bindFinanceFilters(renderFinance);
  bindReportFilters(renderReports);

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !$("modal").classList.contains("hidden")) closeModal();
  });
}

function registerServiceWorker() {
  if (!("serviceWorker" in navigator)) return;
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch((error) => {
      console.warn("Service worker não registrado:", error);
    });
  });
}

subscribe(() => renderAll());

bindStaticEvents();
registerServiceWorker();

startFirebase({
  onStatus: setSync,
  onUser: setUser
});

console.info(`Financeiro do Sítio v${APP_VERSION}`);
