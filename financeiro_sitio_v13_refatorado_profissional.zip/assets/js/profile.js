import {
  DEFAULT_REVENUE_CATEGORIES,
  DEFAULT_EXPENSE_CATEGORIES
} from "./config.js";
import { getState, mutate, replaceState } from "./store.js";
import {
  latestSoilForTalhao,
  nomeSafra,
  nomeTalhao
} from "./domain.js";
import {
  $, money, numberBR, dateBR, dateISO, escapeHTML, uid, toNumber,
  nullableNumber, downloadText, clone
} from "./utils.js";
import {
  setModal, showToast, options, field, textInput, numberInput, dateInput,
  selectInput, textareaInput, iconUse
} from "./ui.js";
import { QUOTE_SOURCES, regionalQuote } from "./quote.js";
import { openWorkerForm, openWorkerAccount, deleteWorker } from "./harvest.js";

export function renderProfile(user) {
  const state = getState();
  const email = user?.email || "Usuário";
  const initial = email.charAt(0).toUpperCase();

  $("profileEmail").textContent = email;
  $("profileAvatar").textContent = initial;
  $("profileSafra").textContent = state.safraAtivaId ? nomeSafra(state, state.safraAtivaId) : "Nenhuma";

  $("countWorkers").textContent = state.trabalhadores.length;
  $("countSafras").textContent = state.safras.length;
  $("countTalhoes").textContent = state.talhoes.length;
  $("countSoil").textContent = state.analisesSolo.length;
  $("countCategories").textContent = state.categorias.receita.length + state.categorias.despesa.length;
  $("countPeople").textContent = state.pessoas.length;
  $("quoteDiscountBadge").textContent = money(state.cotacaoCafe.descontoRegional).replace(",00", "");
}

export function openWorkersManager() {
  const render = () => {
    const state = getState();
    $("modalBody").innerHTML = `
      <div class="section-head compact"><div><h3>Colhedores cadastrados</h3><p>Equipe e valor padrão por latão.</p></div><button class="btn small primary" type="button" data-local-action="new-worker">+ Novo</button></div>
      <div class="manage-list">${state.trabalhadores.length
        ? state.trabalhadores.map((w) => `
          <div class="manage-row">
            <div><strong>${escapeHTML(w.nome)}</strong><small>${money(w.valorLatao || 0)} por latão</small></div>
            <div class="row-actions">
              <button class="icon-btn" type="button" data-local-action="account-worker" data-id="${escapeHTML(w.id)}">${iconUse("i-wallet")}</button>
              <button class="icon-btn" type="button" data-local-action="edit-worker" data-id="${escapeHTML(w.id)}">${iconUse("i-edit")}</button>
              <button class="icon-btn" type="button" data-local-action="delete-worker" data-id="${escapeHTML(w.id)}">${iconUse("i-trash")}</button>
            </div>
          </div>`).join("")
        : `<div class="empty">Nenhum colhedor cadastrado.</div>`}
      </div>`;
  };

  setModal({
    eyebrow: "PRODUÇÃO E EQUIPE",
    title: "Colhedores",
    body: "",
    cancelLabel: "Fechar",
    footer: true
  });
  render();

  $("modalBody").onclick = (e) => {
    const btn = e.target.closest("[data-local-action]");
    if (!btn) return;
    const action = btn.dataset.localAction;
    const id = btn.dataset.id || "";
    if (action === "new-worker") openWorkerForm();
    if (action === "edit-worker") openWorkerForm(id);
    if (action === "account-worker") openWorkerAccount(id);
    if (action === "delete-worker") {
      deleteWorker(id);
      setTimeout(render, 20);
    }
  };
}

export function openSafraManager() {
  const render = () => {
    const state = getState();
    $("modalBody").innerHTML = `
      <div class="form-section">
        <h4>Criar nova safra</h4>
        <div class="form-grid three">
          ${field("Nome", textInput("newSafraName", "", `placeholder="Ex.: Safra 2027"`))}
          ${field("Ano", numberInput("newSafraYear", new Date().getFullYear(), `min="2000" max="2100" step="1"`))}
          <div class="field" style="display:flex;align-items:flex-end"><button class="btn primary full" type="button" data-local-action="add-safra">Criar safra</button></div>
        </div>
      </div>
      <div class="manage-list">${state.safras.length
        ? [...state.safras].sort((a,b)=>(b.ano||0)-(a.ano||0)).map((s) => {
            const active = s.id === state.safraAtivaId;
            const used = ["lancamentos","apanhas","lotes","colheitas","vendas"].some((key) =>
              state[key].some((x) => x.safraId === s.id)
            );
            return `<div class="manage-row">
              <div><strong>${escapeHTML(s.nome)}</strong><small>${s.ano || ""}${active ? " • Ativa" : ""}${s.fechada ? " • Fechada" : ""}</small></div>
              <div class="row-actions">
                ${!active && !s.fechada ? `<button class="btn small ghost" type="button" data-local-action="activate-safra" data-id="${escapeHTML(s.id)}">Ativar</button>` : ""}
                <button class="icon-btn" type="button" data-local-action="toggle-safra" data-id="${escapeHTML(s.id)}" title="${s.fechada ? "Reabrir" : "Fechar"}">${s.fechada ? iconUse("i-sync") : iconUse("i-check")}</button>
                ${!used && !active ? `<button class="icon-btn" type="button" data-local-action="delete-safra" data-id="${escapeHTML(s.id)}">${iconUse("i-trash")}</button>` : ""}
              </div>
            </div>`;
          }).join("")
        : `<div class="empty"><strong>Nenhuma safra cadastrada.</strong>Crie a primeira safra para começar a colheita.</div>`}
      </div>`;
  };

  setModal({ eyebrow:"CADASTRO", title:"Safras", body:"", cancelLabel:"Fechar", footer:true });
  render();

  $("modalBody").onclick = (e) => {
    const btn=e.target.closest("[data-local-action]");if(!btn)return;
    const action=btn.dataset.localAction,id=btn.dataset.id||"";
    if(action==="add-safra"){
      const name=$("modalBody").querySelector('[name="newSafraName"]').value.trim();
      const year=Number($("modalBody").querySelector('[name="newSafraYear"]').value)||new Date().getFullYear();
      const finalName=name||`Safra ${year}`;
      mutate((draft)=>{
        const created={id:uid("safra"),nome:finalName,ano:year,fechada:false};
        draft.safras.push(created);draft.safraAtivaId=created.id;
      });
      showToast("Safra criada e definida como ativa.");render();
    }
    if(action==="activate-safra"){
      mutate((draft)=>{const s=draft.safras.find((x)=>x.id===id);if(s&&!s.fechada)draft.safraAtivaId=id;});
      showToast("Safra ativa alterada.");render();
    }
    if(action==="toggle-safra"){
      const state=getState(),s=state.safras.find((x)=>x.id===id);if(!s)return;
      if(!s.fechada&&state.safraAtivaId===id){showToast("Ative outra safra antes de fechar esta.");return}
      mutate((draft)=>{const target=draft.safras.find((x)=>x.id===id);if(target)target.fechada=!target.fechada;});
      render();
    }
    if(action==="delete-safra"){
      if(!confirm("Excluir esta safra vazia?"))return;
      mutate((draft)=>{draft.safras=draft.safras.filter((x)=>x.id!==id)});
      render();
    }
  };
}

export function openTalhaoManager() {
  const render = () => {
    const state=getState();
    $("modalBody").innerHTML=`
      <div class="section-head compact"><div><h3>Talhões cadastrados</h3><p>Área, variedade, plantas e análise de solo.</p></div><button class="btn small primary" type="button" data-local-action="new-talhao">+ Novo</button></div>
      <div class="manage-list">${state.talhoes.length?state.talhoes.map((t)=>{
        const soil=latestSoilForTalhao(state,t.id);
        return `<div class="manage-row">
          <div><strong>${escapeHTML(t.nome)}</strong><small>${escapeHTML(t.variedade||"Variedade não informada")} • ${numberBR(t.area||0)} ha • ${Number(t.plantas||0).toLocaleString("pt-BR")} plantas${soil?` • Solo ${dateBR(soil.data)}`:""}</small></div>
          <div class="row-actions">
            <button class="icon-btn" type="button" data-local-action="new-soil" data-id="${escapeHTML(t.id)}">${iconUse("i-soil")}</button>
            <button class="icon-btn" type="button" data-local-action="edit-talhao" data-id="${escapeHTML(t.id)}">${iconUse("i-edit")}</button>
            <button class="icon-btn" type="button" data-local-action="delete-talhao" data-id="${escapeHTML(t.id)}">${iconUse("i-trash")}</button>
          </div>
        </div>`}).join(""):`<div class="empty">Nenhum talhão cadastrado.</div>`}</div>`;
  };
  setModal({eyebrow:"PRODUÇÃO",title:"Talhões",body:"",cancelLabel:"Fechar",footer:true});
  render();

  $("modalBody").onclick=(e)=>{
    const btn=e.target.closest("[data-local-action]");if(!btn)return;
    const a=btn.dataset.localAction,id=btn.dataset.id||"";
    if(a==="new-talhao")openTalhaoForm();
    if(a==="edit-talhao")openTalhaoForm(id);
    if(a==="new-soil")openSoilForm("",id);
    if(a==="delete-talhao"){
      const state=getState();
      const used=[
        ...state.lancamentos.map((x)=>x.talhaoId),
        ...state.colheitas.map((x)=>x.talhaoId),
        ...state.vendas.map((x)=>x.talhaoId),
        ...state.apanhas.map((x)=>x.talhaoId),
        ...state.analisesSolo.map((x)=>x.talhaoId)
      ].includes(id);
      if(used){showToast("Esse talhão possui registros vinculados e não pode ser excluído.");return}
      if(!confirm("Excluir este talhão?"))return;
      mutate((draft)=>{draft.talhoes=draft.talhoes.filter((x)=>x.id!==id)});render();
    }
  };
}

export function openTalhaoForm(id="") {
  const state=getState(),item=id?state.talhoes.find((x)=>x.id===id):null;if(id&&!item)return;
  const body=`<div class="form-grid">
    ${field("Nome do talhão",textInput("nome",item?.nome||"",`required placeholder="Ex.: Talhão 01"`))}
    ${field("Variedade / clone",textInput("variedade",item?.variedade||"",`placeholder="Ex.: 156, R22, LB15"`))}
    ${field("Área (hectares)",numberInput("area",item?.area??"",`min="0"`))}
    ${field("Quantidade de plantas",numberInput("plantas",item?.plantas??"",`min="0" step="1"`))}
    ${field("Observação",textareaInput("obs",item?.obs||""),{full:true})}
  </div>`;
  setModal({
    eyebrow:"TALHÃO",title:item?"Editar talhão":"Novo talhão",body,submitLabel:"Salvar talhão",
    onSubmit:async(fd)=>{
      const nome=String(fd.get("nome")||"").trim();if(!nome)throw new Error("Informe o nome do talhão.");
      mutate((draft)=>{
        const current=item?draft.talhoes.find((x)=>x.id===item.id):null;
        const next={id:current?.id||uid("talhao"),nome,variedade:String(fd.get("variedade")||"").trim(),area:toNumber(fd.get("area")),plantas:Math.round(toNumber(fd.get("plantas"))),obs:String(fd.get("obs")||"").trim()};
        if(current)Object.assign(current,next);else draft.talhoes.push(next);
      });
      showToast("Talhão salvo.");
    }
  });
}

export function openCategoriesManager() {
  const render=()=>{
    const state=getState();
    const standardRevenue=new Set(DEFAULT_REVENUE_CATEGORIES),standardExpense=new Set(DEFAULT_EXPENSE_CATEGORIES);
    const list=(type,standard)=>state.categorias[type].map((name)=>`<div class="manage-row"><div><strong>${escapeHTML(name)}</strong><small>${standard.has(name)?"Categoria padrão":"Personalizada"}</small></div>${standard.has(name)?"":`<button class="icon-btn" type="button" data-local-action="delete-category" data-type="${type}" data-name="${escapeHTML(encodeURIComponent(name))}">${iconUse("i-trash")}</button>`}</div>`).join("");
    $("modalBody").innerHTML=`
      <div class="form-section"><h4>Nova categoria</h4><div class="form-grid three">
        ${field("Tipo",selectInput("newCategoryType",`<option value="despesa">Despesa</option><option value="receita">Receita</option>`))}
        ${field("Nome",textInput("newCategoryName","",`placeholder="Nome da categoria"`))}
        <div class="field" style="display:flex;align-items:flex-end"><button class="btn primary full" type="button" data-local-action="add-category">Adicionar</button></div>
      </div></div>
      <div class="split-grid" style="margin-top:10px"><div><h4 class="subhead">Receitas</h4><div class="manage-list">${list("receita",standardRevenue)}</div></div><div><h4 class="subhead">Despesas</h4><div class="manage-list">${list("despesa",standardExpense)}</div></div></div>`;
  };
  setModal({eyebrow:"FINANCEIRO",title:"Categorias",body:"",cancelLabel:"Fechar",footer:true,wide:true});render();
  $("modalBody").onclick=(e)=>{
    const btn=e.target.closest("[data-local-action]");if(!btn)return;
    if(btn.dataset.localAction==="add-category"){
      const type=$("modalBody").querySelector('[name="newCategoryType"]').value;
      const name=$("modalBody").querySelector('[name="newCategoryName"]').value.trim();
      if(!name){showToast("Informe o nome da categoria.");return}
      mutate((draft)=>{if(!draft.categorias[type].some((x)=>x.toLowerCase()===name.toLowerCase()))draft.categorias[type].push(name)});
      render();
    }
    if(btn.dataset.localAction==="delete-category"){
      const type=btn.dataset.type,name=decodeURIComponent(btn.dataset.name);
      const used=getState().lancamentos.some((x)=>x.tipo===type&&x.categoria===name);
      if(used&&!confirm("Essa categoria aparece em lançamentos antigos. Remover apenas da lista de novos lançamentos?"))return;
      mutate((draft)=>{draft.categorias[type]=draft.categorias[type].filter((x)=>x!==name)});
      render();
    }
  };
}

export function openPeopleManager() {
  const render=()=>{
    const state=getState();
    $("modalBody").innerHTML=`
      <div class="section-head compact"><div><h3>Pessoas e empresas</h3><p>Fornecedores e compradores usados nos lançamentos.</p></div><button class="btn small primary" type="button" data-local-action="new-person">+ Novo</button></div>
      <div class="manage-list">${state.pessoas.length?state.pessoas.map((p)=>`<div class="manage-row"><div><strong>${escapeHTML(p.nome)}</strong><small>${p.tipo==="fornecedor"?"Fornecedor":p.tipo==="comprador"?"Comprador":"Fornecedor e comprador"}${p.telefone?` • ${escapeHTML(p.telefone)}`:""}</small></div><div class="row-actions"><button class="icon-btn" type="button" data-local-action="edit-person" data-id="${escapeHTML(p.id)}">${iconUse("i-edit")}</button><button class="icon-btn" type="button" data-local-action="delete-person" data-id="${escapeHTML(p.id)}">${iconUse("i-trash")}</button></div></div>`).join(""):`<div class="empty">Nenhuma pessoa ou empresa cadastrada.</div>`}</div>`;
  };
  setModal({eyebrow:"NEGOCIAÇÕES",title:"Fornecedores e compradores",body:"",cancelLabel:"Fechar",footer:true});render();
  $("modalBody").onclick=(e)=>{
    const btn=e.target.closest("[data-local-action]");if(!btn)return;
    const a=btn.dataset.localAction,id=btn.dataset.id||"";
    if(a==="new-person")openPersonForm();
    if(a==="edit-person")openPersonForm(id);
    if(a==="delete-person"){
      const used=getState().lancamentos.some((x)=>x.pessoaId===id)||getState().vendas.some((x)=>x.pessoaId===id);
      if(used){showToast("Este cadastro já está vinculado a movimentações.");return}
      if(!confirm("Excluir este cadastro?"))return;
      mutate((draft)=>{draft.pessoas=draft.pessoas.filter((x)=>x.id!==id)});render();
    }
  };
}

export function openPersonForm(id=""){
  const state=getState(),item=id?state.pessoas.find((x)=>x.id===id):null;if(id&&!item)return;
  const body=`<div class="form-grid">
    ${field("Nome / razão social",textInput("nome",item?.nome||"",`required`))}
    ${field("Tipo",selectInput("tipo",`<option value="fornecedor"${item?.tipo==="fornecedor"?" selected":""}>Fornecedor</option><option value="comprador"${item?.tipo==="comprador"?" selected":""}>Comprador</option><option value="ambos"${item?.tipo==="ambos"||!item?" selected":""}>Fornecedor e comprador</option>`))}
    ${field("Documento",textInput("documento",item?.documento||"",`placeholder="CPF/CNPJ (opcional)"`))}
    ${field("Telefone",textInput("telefone",item?.telefone||"",`placeholder="(00) 00000-0000"`))}
    ${field("Observação",textareaInput("obs",item?.obs||""),{full:true})}
  </div>`;
  setModal({
    eyebrow:"CADASTRO",title:item?"Editar cadastro":"Nova pessoa / empresa",body,submitLabel:"Salvar",
    onSubmit:async(fd)=>{
      const nome=String(fd.get("nome")||"").trim();if(!nome)throw new Error("Informe o nome.");
      mutate((draft)=>{
        const current=item?draft.pessoas.find((x)=>x.id===item.id):null;
        const next={id:current?.id||uid("pessoa"),nome,tipo:String(fd.get("tipo")||"ambos"),documento:String(fd.get("documento")||"").trim(),telefone:String(fd.get("telefone")||"").trim(),obs:String(fd.get("obs")||"").trim()};
        if(current)Object.assign(current,next);else draft.pessoas.push(next);
      });
      showToast("Cadastro salvo.");
    }
  });
}

export function openSoilManager() {
  const render=()=>{
    const state=getState();
    $("modalBody").innerHTML=`
      <div class="section-head compact"><div><h3>Análises cadastradas</h3><p>Histórico químico por talhão e profundidade.</p></div><button class="btn small primary" type="button" data-local-action="new-soil">+ Nova</button></div>
      <div class="manage-list">${state.analisesSolo.length?[...state.analisesSolo].sort((a,b)=>String(b.data||"").localeCompare(String(a.data||""))).map((a)=>`<div class="manage-row"><div><strong>${escapeHTML(nomeTalhao(state,a.talhaoId))} • ${dateBR(a.data)}</strong><small>${escapeHTML(a.profundidade||"")} • pH ${formatSoil(a.ph)} • P ${formatSoil(a.p)} • K ${formatSoil(a.k)} • V% ${formatSoil(a.v)}</small></div><div class="row-actions"><button class="icon-btn" type="button" data-local-action="edit-soil" data-id="${escapeHTML(a.id)}">${iconUse("i-edit")}</button><button class="icon-btn" type="button" data-local-action="delete-soil" data-id="${escapeHTML(a.id)}">${iconUse("i-trash")}</button></div></div>`).join(""):`<div class="empty">Nenhuma análise de solo cadastrada.</div>`}</div>`;
  };
  setModal({eyebrow:"SOLO",title:"Análises de solo",body:"",cancelLabel:"Fechar",footer:true,wide:true});render();
  $("modalBody").onclick=(e)=>{
    const btn=e.target.closest("[data-local-action]");if(!btn)return;
    const a=btn.dataset.localAction,id=btn.dataset.id||"";
    if(a==="new-soil")openSoilForm();
    if(a==="edit-soil")openSoilForm(id);
    if(a==="delete-soil"){
      if(!confirm("Excluir esta análise de solo?"))return;
      mutate((draft)=>{draft.analisesSolo=draft.analisesSolo.filter((x)=>x.id!==id)});render();
    }
  };
}

function formatSoil(v){const n=nullableNumber(v);return n===null?"—":numberBR(n)}

export function openSoilForm(id="",talhaoId=""){
  const state=getState();
  if(!state.talhoes.length){showToast("Cadastre um talhão primeiro.");return}
  const item=id?state.analisesSolo.find((x)=>x.id===id):null;if(id&&!item)return;
  const selectedTalhao=item?.talhaoId||talhaoId||(state.talhoes.length===1?state.talhoes[0].id:"");
  const n=(name,label,value,unit)=>field(label,numberInput(name,value??"",`step="0.01"`),{hint:unit});
  const body=`<div class="form-grid">
    ${field("Data da coleta / análise",dateInput("data",item?.data||dateISO()))}
    ${field("Talhão",selectInput("talhaoId",options(state.talhoes,selectedTalhao,{includeEmpty:true,emptyLabel:"Selecione"})))}
    ${field("Profundidade",selectInput("profundidade",["0-20 cm","20-40 cm","0-10 cm","Outro"].map((x)=>`<option value="${x}"${(item?.profundidade||"0-20 cm")===x?" selected":""}>${x}</option>`).join("")))}
    ${field("Identificação da amostra",textInput("amostra",item?.amostra||"",`placeholder="Ex.: T1-2026-01"`))}
    ${field("Laboratório",textInput("laboratorio",item?.laboratorio||""))}
    ${field("Método",textInput("metodo",item?.metodo||"",`placeholder="Ex.: Mehlich-1, pH em água"`))}
  </div>
  <div class="form-section"><h4>Acidez e matéria orgânica</h4><div class="soil-grid">
    ${n("ph","pH",item?.ph,"conforme método do laboratório")}
    ${n("mo","Matéria orgânica",item?.mo,"g/dm³ ou unidade do laudo")}
    ${n("al","Al",item?.al,"cmolc/dm³")}
    ${n("hAl","H + Al",item?.hAl,"cmolc/dm³")}
  </div></div>
  <div class="form-section"><h4>Macronutrientes e bases</h4><div class="soil-grid">
    ${n("p","Fósforo (P)",item?.p,"mg/dm³")}
    ${n("k","Potássio (K)",item?.k,"mg/dm³")}
    ${n("ca","Cálcio (Ca)",item?.ca,"cmolc/dm³")}
    ${n("mg","Magnésio (Mg)",item?.mg,"cmolc/dm³")}
    ${n("s","Enxofre (S)",item?.s,"mg/dm³")}
    ${n("ctc","CTC (T)",item?.ctc,"cmolc/dm³")}
    ${n("v","Saturação por bases (V)",item?.v,"%")}
    ${n("m","Saturação por Al (m)",item?.m,"%")}
  </div></div>
  <div class="form-section"><h4>Micronutrientes e textura</h4><div class="soil-grid">
    ${n("b","Boro (B)",item?.b,"mg/dm³")}
    ${n("zn","Zinco (Zn)",item?.zn,"mg/dm³")}
    ${n("cu","Cobre (Cu)",item?.cu,"mg/dm³")}
    ${n("mn","Manganês (Mn)",item?.mn,"mg/dm³")}
    ${n("fe","Ferro (Fe)",item?.fe,"mg/dm³")}
    ${n("argila","Argila",item?.argila,"%")}
  </div></div>
  <div class="form-grid" style="margin-top:8px">${field("Observações do laudo / recomendação técnica",textareaInput("obs",item?.obs||""),{full:true})}</div>
  <div class="form-hint">O app organiza os resultados, mas não prescreve automaticamente doses de calcário, gesso ou adubos.</div>`;

  setModal({
    eyebrow:"ANÁLISE DE SOLO",title:item?"Editar análise":"Nova análise de solo",body,submitLabel:"Salvar análise",wide:true,
    onSubmit:async(fd)=>{
      const tid=String(fd.get("talhaoId")||"");if(!tid)throw new Error("Selecione o talhão.");
      mutate((draft)=>{
        const current=item?draft.analisesSolo.find((x)=>x.id===item.id):null;
        const next={
          id:current?.id||uid("solo"),data:String(fd.get("data")||dateISO()),talhaoId:tid,
          profundidade:String(fd.get("profundidade")||"0-20 cm"),amostra:String(fd.get("amostra")||"").trim(),
          laboratorio:String(fd.get("laboratorio")||"").trim(),metodo:String(fd.get("metodo")||"").trim(),
          ph:nullableNumber(fd.get("ph")),mo:nullableNumber(fd.get("mo")),al:nullableNumber(fd.get("al")),hAl:nullableNumber(fd.get("hAl")),
          p:nullableNumber(fd.get("p")),k:nullableNumber(fd.get("k")),ca:nullableNumber(fd.get("ca")),mg:nullableNumber(fd.get("mg")),
          s:nullableNumber(fd.get("s")),ctc:nullableNumber(fd.get("ctc")),v:nullableNumber(fd.get("v")),m:nullableNumber(fd.get("m")),
          b:nullableNumber(fd.get("b")),zn:nullableNumber(fd.get("zn")),cu:nullableNumber(fd.get("cu")),mn:nullableNumber(fd.get("mn")),
          fe:nullableNumber(fd.get("fe")),argila:nullableNumber(fd.get("argila")),obs:String(fd.get("obs")||"").trim()
        };
        if(current)Object.assign(current,next);else draft.analisesSolo.push(next);
      });
      showToast("Análise de solo salva.");
    }
  });
}

export function openQuoteSettings(onRefresh){
  const state=getState(),q=state.cotacaoCafe;
  const sourceOptions=[
    ["auto","Automático (recomendado)"],
    ...Object.entries(QUOTE_SOURCES).map(([key,s])=>[key,s.name])
  ].map(([key,label])=>`<option value="${escapeHTML(key)}"${q.fontePreferida===key?" selected":""}>${escapeHTML(label)}</option>`).join("");
  const body=`<div class="form-grid">
    ${field("Fonte preferida",selectInput("fontePreferida",sourceOptions))}
    ${field("Diferença na sua região (R$/saca)",numberInput("descontoRegional",q.descontoRegional??80,`min="0"`))}
    ${field("Cotação manual de referência",numberInput("precoManual",q.precoPainel||"",`min="0"`),{hint:"Use somente como contingência; a atualização automática continua ativa."})}
  </div>
  <div class="inline-kpis">
    <article><small>Referência atual</small><strong>${q.precoPainel?money(q.precoPainel):"—"}</strong></article>
    <article><small>Estimativa regional</small><strong>${regionalQuote(q)?money(regionalQuote(q)):"—"}</strong></article>
    <article><small>Fonte atual</small><strong>${escapeHTML(q.fonteAtual||"—")}</strong></article>
    <article><small>Data fonte</small><strong>${escapeHTML(q.dataFonte||"—")}</strong></article>
  </div>
  <div class="form-hint">A estimativa regional é calculada como referência de mercado − diferença configurada. Não é uma cotação oficial da sua cidade.</div>`;
  setModal({
    eyebrow:"COTAÇÃO DO CAFÉ",title:"Configurar referência",body,submitLabel:"Salvar e atualizar",
    onSubmit:async(fd)=>{
      mutate((draft)=>{
        draft.cotacaoCafe.fontePreferida=String(fd.get("fontePreferida")||"auto");
        draft.cotacaoCafe.descontoRegional=Math.max(0,toNumber(fd.get("descontoRegional")));
        const manual=toNumber(fd.get("precoManual"));
        if(manual>0&&Math.abs(manual-toNumber(draft.cotacaoCafe.precoPainel))>.001){
          draft.cotacaoCafe.precoPainel=manual;draft.cotacaoCafe.atualizadoEm=new Date().toISOString();
          draft.cotacaoCafe.origem="manual";draft.cotacaoCafe.fonteAtual="Valor manual";draft.cotacaoCafe.urlFonteAtual="";
        }
      });
      showToast("Configuração salva. Atualizando cotação...");
      await onRefresh?.(true);
    }
  });
}

export function downloadBackup(){
  const state=clone(getState());
  downloadText(`financeiro-sitio-backup-${dateISO()}.json`,JSON.stringify(state,null,2),"application/json;charset=utf-8");
  showToast("Backup gerado.");
}

export async function importBackupFile(file){
  if(!file)return;
  const text=await file.text();
  let raw;
  try{raw=JSON.parse(text)}catch{throw new Error("Arquivo JSON inválido.")}
  if(!raw||typeof raw!=="object"||!Array.isArray(raw.lancamentos)||!Array.isArray(raw.talhoes)){
    throw new Error("Este arquivo não parece ser um backup do Financeiro do Sítio.");
  }
  if(!confirm("Importar este backup substituirá os dados atuais desta conta. Continuar?"))return;
  replaceState(raw,"local");
  showToast("Backup importado. O Firebase será atualizado.");
}
