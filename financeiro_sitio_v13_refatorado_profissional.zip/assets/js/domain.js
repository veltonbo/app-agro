import { toNumber, dateISO, daysBetween, sortByDateAsc } from "./utils.js";

export function byId(list, id) {
  return list.find((item) => item?.id === id) || null;
}

export function safraById(state, id) {
  return byId(state.safras, id);
}

export function talhaoById(state, id) {
  return byId(state.talhoes, id);
}

export function trabalhadorById(state, id) {
  return byId(state.trabalhadores, id);
}

export function pessoaById(state, id) {
  return byId(state.pessoas, id);
}

export function nomeSafra(state, id) {
  return safraById(state, id)?.nome || "Sem safra";
}

export function nomeTalhao(state, id) {
  return talhaoById(state, id)?.nome || "Sem talhão";
}

export function nomeTrabalhador(state, id) {
  return trabalhadorById(state, id)?.nome || "Colhedor";
}

export function nomePessoa(state, id) {
  return pessoaById(state, id)?.nome || "";
}

export function calcGlobalSummary(state) {
  const receitas = state.lancamentos
    .filter((x) => x.tipo === "receita" && x.status === "pago")
    .reduce((s, x) => s + toNumber(x.valor), 0);

  const despesas = state.lancamentos
    .filter((x) => x.tipo === "despesa" && x.status === "pago")
    .reduce((s, x) => s + toNumber(x.valor), 0);

  const receber = state.lancamentos
    .filter((x) => x.tipo === "receita" && x.status !== "pago")
    .reduce((s, x) => s + toNumber(x.valor), 0);

  const pagar = state.lancamentos
    .filter((x) => x.tipo === "despesa" && x.status !== "pago")
    .reduce((s, x) => s + toNumber(x.valor), 0);

  const produzido = state.colheitas.reduce((s, x) => s + toNumber(x.sacas), 0);
  const vendido = state.vendas.reduce((s, x) => s + toNumber(x.sacas), 0);
  const estoque = Math.max(0, produzido - vendido);

  return {
    receitas,
    despesas,
    receber,
    pagar,
    saldo: receitas - despesas,
    produzido,
    vendido,
    estoque
  };
}

export function filterBySafra(list, safraId) {
  if (!safraId || safraId === "todos") return [...list];
  return list.filter((x) => x.safraId === safraId);
}

export function calcSafraSummary(state, safraId) {
  if (!safraId) {
    return {
      receitas: 0,
      despesas: 0,
      resultado: 0,
      receber: 0,
      pagar: 0,
      produzido: 0,
      vendido: 0,
      estoque: 0,
      valorVendas: 0,
      custoSaca: 0,
      precoMedio: 0,
      margemSaca: 0
    };
  }

  const lancamentos = filterBySafra(state.lancamentos, safraId);
  const colheitas = filterBySafra(state.colheitas, safraId);
  const vendas = filterBySafra(state.vendas, safraId);

  const receitas = lancamentos
    .filter((x) => x.tipo === "receita" && x.status === "pago")
    .reduce((s, x) => s + toNumber(x.valor), 0);

  const despesas = lancamentos
    .filter((x) => x.tipo === "despesa" && x.status === "pago")
    .reduce((s, x) => s + toNumber(x.valor), 0);

  const receber = lancamentos
    .filter((x) => x.tipo === "receita" && x.status !== "pago")
    .reduce((s, x) => s + toNumber(x.valor), 0);

  const pagar = lancamentos
    .filter((x) => x.tipo === "despesa" && x.status !== "pago")
    .reduce((s, x) => s + toNumber(x.valor), 0);

  const produzido = colheitas.reduce((s, x) => s + toNumber(x.sacas), 0);
  const vendido = vendas.reduce((s, x) => s + toNumber(x.sacas), 0);
  const valorVendas = vendas.reduce((s, x) => s + toNumber(x.total), 0);
  const estoque = Math.max(0, produzido - vendido);
  const custoSaca = produzido > 0 ? despesas / produzido : 0;
  const precoMedio = vendido > 0 ? valorVendas / vendido : 0;

  return {
    receitas,
    despesas,
    resultado: receitas - despesas,
    receber,
    pagar,
    produzido,
    vendido,
    estoque,
    valorVendas,
    custoSaca,
    precoMedio,
    margemSaca: precoMedio - custoSaca
  };
}

export function stockForSafra(state, safraId, ignoreVendaId = "") {
  const produzido = state.colheitas
    .filter((x) => x.safraId === safraId)
    .reduce((s, x) => s + toNumber(x.sacas), 0);

  const vendido = state.vendas
    .filter((x) => x.safraId === safraId && x.id !== ignoreVendaId)
    .reduce((s, x) => s + toNumber(x.sacas), 0);

  return Math.max(0, produzido - vendido);
}

export function classifyPendingAccount(item, today = dateISO()) {
  if (item.status === "pago") return "pago";
  if (!item.vencimento) return "sem-vencimento";
  const diff = daysBetween(today, item.vencimento);
  if (diff === null) return "sem-vencimento";
  if (diff < 0) return "vencida";
  if (diff === 0) return "hoje";
  if (diff <= 7) return "proxima";
  return "futura";
}

export function getPendingAccounts(state, type = "despesa", today = dateISO()) {
  const items = state.lancamentos
    .filter((x) => x.tipo === type && x.status !== "pago")
    .map((x) => ({ ...x, situacao: classifyPendingAccount(x, today) }));

  items.sort((a, b) => {
    const aDate = a.vencimento || "9999-12-31";
    const bDate = b.vencimento || "9999-12-31";
    if (aDate !== bDate) return aDate.localeCompare(bDate);
    return String(b.data || "").localeCompare(String(a.data || ""));
  });
  return items;
}

export function accountsPayableSummary(state, today = dateISO()) {
  const items = getPendingAccounts(state, "despesa", today);
  const total = items.reduce((s, x) => s + toNumber(x.valor), 0);
  const vencido = items
    .filter((x) => x.situacao === "vencida")
    .reduce((s, x) => s + toNumber(x.valor), 0);
  const hoje = items
    .filter((x) => x.situacao === "hoje")
    .reduce((s, x) => s + toNumber(x.valor), 0);
  const proximos7 = items
    .filter((x) => ["hoje", "proxima"].includes(x.situacao))
    .reduce((s, x) => s + toNumber(x.valor), 0);
  return { items, total, vencido, hoje, proximos7, quantidade: items.length };
}

export function workerStats(state, workerId, safraId = "todos") {
  const apanhas = state.apanhas.filter(
    (x) => x.trabalhadorId === workerId && (safraId === "todos" || !safraId || x.safraId === safraId)
  );

  return apanhas.reduce(
    (acc, x) => {
      const total = toNumber(x.latoes) * toNumber(x.valorLatao);
      acc.latoes += toNumber(x.latoes);
      acc.total += total;
      if (x.status === "pago") acc.pago += total;
      else acc.pendente += total;
      return acc;
    },
    { latoes: 0, total: 0, pago: 0, pendente: 0, registros: apanhas.length }
  );
}

export function allocatedForApanha(state, apanhaId, ignoreLoteId = "") {
  return state.lotes
    .filter((lote) => lote.id !== ignoreLoteId)
    .reduce((sum, lote) => {
      const alocacoes = Array.isArray(lote.alocacoes) ? lote.alocacoes : [];
      return (
        sum +
        alocacoes
          .filter((x) => x.apanhaId === apanhaId)
          .reduce((s, x) => s + toNumber(x.latoes), 0)
      );
    }, 0);
}

export function availableForApanha(state, apanha, ignoreLoteId = "") {
  return Math.max(0, toNumber(apanha.latoes) - allocatedForApanha(state, apanha.id, ignoreLoteId));
}

export function availableLatoes(state, { safraId, talhaoId = "todos", ignoreLoteId = "" } = {}) {
  return state.apanhas
    .filter((apanha) => {
      if (safraId && apanha.safraId !== safraId) return false;
      if (talhaoId && talhaoId !== "todos" && apanha.talhaoId !== talhaoId) return false;
      return availableForApanha(state, apanha, ignoreLoteId) > 0.00001;
    })
    .reduce((sum, apanha) => sum + availableForApanha(state, apanha, ignoreLoteId), 0);
}

export function allocateLatoes(
  state,
  quantity,
  { safraId, talhaoId = "todos", ignoreLoteId = "" } = {}
) {
  let remaining = Math.max(0, toNumber(quantity));
  const alocacoes = [];

  const candidates = state.apanhas
    .filter((apanha) => {
      if (safraId && apanha.safraId !== safraId) return false;
      if (talhaoId && talhaoId !== "todos" && apanha.talhaoId !== talhaoId) return false;
      return availableForApanha(state, apanha, ignoreLoteId) > 0.00001;
    })
    .sort((a, b) => sortByDateAsc(a, b, "data"));

  for (const apanha of candidates) {
    if (remaining <= 0.00001) break;
    const available = availableForApanha(state, apanha, ignoreLoteId);
    const use = Math.min(available, remaining);
    if (use > 0.00001) {
      alocacoes.push({ apanhaId: apanha.id, latoes: Number(use.toFixed(4)) });
      remaining -= use;
    }
  }

  return {
    alocacoes,
    faltante: Math.max(0, Number(remaining.toFixed(4)))
  };
}

export function lotStats(state, lote) {
  const alocacoes = Array.isArray(lote?.alocacoes) ? lote.alocacoes : [];
  let latoes = 0;
  let custoColheita = 0;
  const workers = new Set();
  const talhoes = new Set();

  for (const alocacao of alocacoes) {
    const apanha = byId(state.apanhas, alocacao.apanhaId);
    if (!apanha) continue;
    const q = toNumber(alocacao.latoes);
    latoes += q;
    custoColheita += q * toNumber(apanha.valorLatao);
    if (apanha.trabalhadorId) workers.add(apanha.trabalhadorId);
    if (apanha.talhaoId) talhoes.add(apanha.talhaoId);
  }

  const sacas = toNumber(lote?.sacas);
  return {
    latoes,
    custoColheita,
    trabalhadores: workers.size,
    talhoes: [...talhoes],
    sacas,
    latoesPorSaca: sacas > 0 ? latoes / sacas : 0,
    custoColheitaPorSaca: sacas > 0 ? custoColheita / sacas : 0
  };
}

export function latestSoilForTalhao(state, talhaoId) {
  return state.analisesSolo
    .filter((x) => x.talhaoId === talhaoId)
    .sort((a, b) => String(b.data || "").localeCompare(String(a.data || "")))[0] || null;
}

export function expensesByCategory(lancamentos) {
  const map = new Map();
  for (const item of lancamentos) {
    if (item.tipo !== "despesa" || item.status !== "pago") continue;
    const key = item.categoria || "Sem categoria";
    map.set(key, (map.get(key) || 0) + toNumber(item.valor));
  }
  return [...map.entries()]
    .map(([categoria, valor]) => ({ categoria, valor }))
    .sort((a, b) => b.valor - a.valor);
}

export function talhaoPerformance(state, filters = {}) {
  const { safraId = "todos", start = "", end = "" } = filters;

  const inRange = (x) =>
    (!start || !x.data || x.data >= start) &&
    (!end || !x.data || x.data <= end) &&
    (safraId === "todos" || !safraId || x.safraId === safraId);

  return state.talhoes.map((talhao) => {
    const despesas = state.lancamentos
      .filter((x) => x.talhaoId === talhao.id && x.tipo === "despesa" && x.status === "pago" && inRange(x))
      .reduce((s, x) => s + toNumber(x.valor), 0);

    const receitas = state.lancamentos
      .filter((x) => x.talhaoId === talhao.id && x.tipo === "receita" && x.status === "pago" && inRange(x))
      .reduce((s, x) => s + toNumber(x.valor), 0);

    const produzido = state.colheitas
      .filter((x) => x.talhaoId === talhao.id && inRange(x))
      .reduce((s, x) => s + toNumber(x.sacas), 0);

    return {
      talhao,
      despesas,
      receitas,
      resultado: receitas - despesas,
      produzido,
      custoSaca: produzido > 0 ? despesas / produzido : 0,
      custoHectare: toNumber(talhao.area) > 0 ? despesas / toNumber(talhao.area) : 0,
      custoPlanta: toNumber(talhao.plantas) > 0 ? despesas / toNumber(talhao.plantas) : 0
    };
  });
}

export function filterRecords(list, { start = "", end = "", safraId = "todos", talhaoId = "todos" } = {}) {
  return list.filter((x) => {
    const okDate = (!start || !x.data || x.data >= start) && (!end || !x.data || x.data <= end);
    const okSafra = safraId === "todos" || !safraId || x.safraId === safraId;
    const okTalhao = talhaoId === "todos" || !talhaoId || x.talhaoId === talhaoId;
    return okDate && okSafra && okTalhao;
  });
}
