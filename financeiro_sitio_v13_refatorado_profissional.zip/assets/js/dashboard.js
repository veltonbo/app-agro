import { getState } from "./store.js";
import {
  accountsPayableSummary,
  calcGlobalSummary,
  calcSafraSummary,
  nomePessoa,
  nomeSafra,
  nomeTalhao
} from "./domain.js";
import { $, money, numberBR, dateBR, escapeHTML, sortByDateDesc } from "./utils.js";
import { options, iconUse } from "./ui.js";
import { regionalQuote } from "./quote.js";

function dashboardAccountRow(item) {
  const state = getState();
  const meta = [
    item.vencimento ? `Vence ${dateBR(item.vencimento)}` : "Sem vencimento",
    item.pessoaId ? nomePessoa(state, item.pessoaId) : "",
    item.categoria
  ].filter(Boolean).join(" • ");

  return `<div class="list-row">
    <span class="row-icon red">${iconUse("i-alert")}</span>
    <div class="row-main">
      <strong>${escapeHTML(item.descricao || item.categoria || "Conta")}</strong>
      <small>${escapeHTML(meta)}</small>
    </div>
    <div class="row-value">
      <strong>${money(item.valor)}</strong>
      <div class="row-actions">
        <button class="icon-btn" type="button" data-action="toggle-launch-paid" data-id="${escapeHTML(item.id)}" title="Marcar pago">${iconUse("i-check")}</button>
      </div>
    </div>
  </div>`;
}

function recentRow(item) {
  const state = getState();
  const meta = [
    dateBR(item.data),
    item.categoria,
    item.talhaoId ? nomeTalhao(state, item.talhaoId) : "",
    item.safraId ? nomeSafra(state, item.safraId) : ""
  ].filter(Boolean).join(" • ");

  return `<div class="list-row">
    <span class="row-icon ${item.tipo === "despesa" ? "red" : "blue"}">${iconUse(item.tipo === "despesa" ? "i-minus" : "i-plus")}</span>
    <div class="row-main">
      <strong>${escapeHTML(item.descricao || item.categoria || "Lançamento")}</strong>
      <small>${escapeHTML(meta)}</small>
    </div>
    <div class="row-value">
      <strong>${item.tipo === "despesa" ? "− " : "+ "}${money(item.valor)}</strong>
      <small>${item.status === "pago" ? (item.tipo === "despesa" ? "Pago" : "Recebido") : (item.tipo === "despesa" ? "A pagar" : "A receber")}</small>
    </div>
  </div>`;
}

export function renderDashboard(syncStatus = "") {
  const state = getState();
  const global = calcGlobalSummary(state);
  const activeId = state.safraAtivaId;
  const active = calcSafraSummary(state, activeId);
  const safra = state.safras.find((x) => x.id === activeId);

  $("metricSaldo").textContent = money(global.saldo);
  $("metricPagar").textContent = money(global.pagar);
  $("metricReceber").textContent = money(global.receber);
  $("metricEstoque").textContent = `${numberBR(global.estoque)} sc`;
  $("metricReceitas").textContent = money(global.receitas);
  $("metricDespesas").textContent = money(global.despesas);
  $("metricSafraProducao").textContent = `${numberBR(active.produzido)} sc`;
  $("metricCustoSaca").textContent = money(active.custoSaca);
  $("metricPrecoMedio").textContent = money(active.precoMedio);
  $("metricMargem").textContent = money(active.margemSaca);

  $("dashSafraNome").textContent = safra?.nome || "Nenhuma safra ativa";
  $("profileSafra").textContent = safra?.nome || "Nenhuma";

  const select = $("dashSafraSelect");
  const current = activeId;
  select.innerHTML = state.safras.length
    ? options(state.safras.filter((x) => !x.fechada), current, { getValue: (x) => x.id, getLabel: (x) => x.nome })
    : `<option value="">Cadastre uma safra</option>`;
  select.value = [...select.options].some((o) => o.value === current) ? current : (select.options[0]?.value || "");
  select.disabled = state.safras.filter((x) => !x.fechada).length === 0;

  const quote = state.cotacaoCafe;
  const regional = regionalQuote(quote);
  $("dashQuoteSource").textContent = quote.fonteAtual || "Cotação Conilon 7/8";
  $("dashQuotePrice").textContent = regional > 0 ? money(regional) : "—";
  $("dashQuoteMeta").textContent = quote.precoPainel > 0
    ? `${quote.dataFonte ? `${quote.dataFonte} • ` : ""}Referência ${money(quote.precoPainel)} − ${money(quote.descontoRegional)}`
    : "Buscando referência de mercado...";

  const payable = accountsPayableSummary(state).items.slice(0, 5);
  $("dashboardAccounts").innerHTML = payable.length
    ? payable.map(dashboardAccountRow).join("")
    : `<div class="empty"><strong>Nenhuma conta pendente.</strong>As próximas contas aparecerão aqui.</div>`;

  const recent = [...state.lancamentos].sort((a,b)=>sortByDateDesc(a,b,"data")).slice(0,6);
  $("dashboardRecent").innerHTML = recent.length
    ? recent.map(recentRow).join("")
    : `<div class="empty"><strong>Nenhuma movimentação ainda.</strong>Use as ações rápidas para começar.</div>`;

  if (syncStatus) {
    $("heroSync").textContent = syncStatus;
  }
}
