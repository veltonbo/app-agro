# Financeiro do Sítio — V13

Aplicativo PWA para gestão financeira e produtiva de café Conilon.

## O que foi reorganizado

A V13 substitui o antigo `index.html` monolítico por uma estrutura modular:

```text
index.html
assets/
  css/
    app.css
  js/
    app.js
    config.js
    dashboard.js
    domain.js
    finance.js
    firebase.js
    harvest.js
    profile.js
    quote.js
    reports.js
    store.js
    ui.js
    utils.js
tests/
  domain.test.mjs
  static.test.mjs
  store.test.mjs
```

A lógica de negócio agora fica separada da interface e do Firebase.

## Principais correções

- Remove dezenas de funções duplicadas e sobrescritas das versões antigas.
- Elimina handlers `onclick` inline.
- Centraliza estado e migração de dados em `store.js`.
- Centraliza cálculos em funções puras de `domain.js`.
- Mantém contas a pagar, contas a receber, saldo e estoque como dados globais, sem desaparecer ao trocar a safra ativa.
- A safra ativa serve principalmente como padrão para novos registros e análise específica.
- Usuário novo inicia sem lançamentos, talhões, safras, colhedores, produção ou vendas.
- Mantém compatibilidade com o modelo de dados das versões anteriores.
- Migra automaticamente lotes antigos com `apanhaIds` para `alocacoes`.
- Service Worker passa a cachear somente arquivos do próprio app e não interfere no Firebase nem nas fontes externas de cotação.
- Lançamentos vinculados a colheitas e vendas preservam a sincronização do status financeiro.
- Venda valida estoque da safra antes de salvar.
- Envio ao secador aloca apenas a quantidade solicitada, começando pelos registros mais antigos.

## Recursos

### Financeiro
- Receitas e despesas.
- Contas a pagar e a receber.
- Vencimento, fornecedor/comprador, parcela, documento e observação.
- Categorias padrão e personalizadas.
- Filtros por texto, tipo, status, safra, talhão e categoria.

### Colheita
- Colhedores e valor por latão.
- Conta individual do colhedor.
- Colheita por latão.
- Envio ao secador por quantidade, sem selecionar colhedor por colhedor.
- Fechamento do lote após secagem e limpeza.
- Conversão de latões para sacas.
- Produção e estoque.
- Vendas com baixa automática do estoque.

### Perfil
- Safras.
- Talhões.
- Colhedores.
- Categorias.
- Fornecedores e compradores.
- Cotação do café.
- Análises de solo.
- Backup JSON.

### Análise de solo
- pH, matéria orgânica, Al, H+Al.
- P, K, Ca, Mg, S.
- CTC, V%, m%.
- B, Zn, Cu, Mn, Fe e argila.
- Histórico por talhão e profundidade.

### Relatórios
- Resultado financeiro.
- Custo por saca.
- Despesas por categoria.
- Resultado por talhão.
- Resumo de colhedores.
- Última análise de solo por talhão.
- Exportação CSV e impressão/PDF.

## Firebase

O caminho continua:

```text
financeiroSitio
└── users
    └── UID_DO_USUARIO
        └── estado
```

As regras permanecem compatíveis com o Viveiro Café e o Financeiro do Sítio.

## Testes

Não há dependências npm externas.

```bash
npm test
```

Os testes verificam cálculos de estoque, contas globais, secador, colhedores, migração de dados, IDs duplicados, handlers inline e assets do Service Worker.

## Publicação

O projeto continua compatível com GitHub Pages. Não há etapa de build.
