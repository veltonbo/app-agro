import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, existsSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, "..");
const html = readFileSync(resolve(root, "index.html"), "utf8");
const app = readFileSync(resolve(root, "assets/js/app.js"), "utf8");
const sw = readFileSync(resolve(root, "sw.js"), "utf8");

test("index não contém IDs duplicados", () => {
  const ids = [...html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]);
  const dup = ids.filter((id, i) => ids.indexOf(id) !== i);
  assert.deepEqual([...new Set(dup)], []);
});

test("não existem handlers inline no HTML", () => {
  assert.equal(/\son(click|change|input|submit)=/i.test(html), false);
});

test("todas as ações declaradas no HTML têm handler no app", () => {
  const actions = [...html.matchAll(/data-action="([^"]+)"/g)].map((m) => m[1]);
  for (const action of new Set(actions)) {
    assert.match(app, new RegExp(`case "${action.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}"`));
  }
});

test("todos os assets do service worker existem", () => {
  const assets = [...sw.matchAll(/"\.\/([^"]+)"/g)]
    .map((m) => m[1])
    .filter((x) => x && x !== "");
  for (const asset of assets) {
    assert.ok(existsSync(resolve(root, asset)), `Asset ausente: ${asset}`);
  }
});
