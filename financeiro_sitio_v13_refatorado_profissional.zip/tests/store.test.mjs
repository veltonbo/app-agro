import test from "node:test";
import assert from "node:assert/strict";
import { emptyState, normalizeState } from "../assets/js/store.js";

test("usuário novo começa sem safra e sem dados operacionais", () => {
  const s = emptyState();
  assert.equal(s.safras.length, 0);
  assert.equal(s.lancamentos.length, 0);
  assert.equal(s.talhoes.length, 0);
  assert.equal(s.apanhas.length, 0);
  assert.equal(s.vendas.length, 0);
});

test("migra lote antigo com apanhaIds", () => {
  const s = normalizeState({
    apanhas:[{id:"a1",latoes:50}],
    lotes:[{id:"l1",apanhaIds:["a1"]}]
  });
  assert.deepEqual(s.lotes[0].alocacoes,[{apanhaId:"a1",latoes:50}]);
  assert.equal("apanhaIds" in s.lotes[0], false);
});

test("mantém categorias personalizadas e padrões", () => {
  const s = normalizeState({
    categorias:{receita:["Minha receita"],despesa:["Minha despesa"]}
  });
  assert.ok(s.categorias.receita.includes("Venda de café"));
  assert.ok(s.categorias.receita.includes("Minha receita"));
  assert.ok(s.categorias.despesa.includes("Colheita"));
  assert.ok(s.categorias.despesa.includes("Minha despesa"));
});
