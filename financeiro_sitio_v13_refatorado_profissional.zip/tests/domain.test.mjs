import test from "node:test";
import assert from "node:assert/strict";
import {
  calcGlobalSummary, calcSafraSummary, accountsPayableSummary,
  allocateLatoes, availableForApanha, stockForSafra, workerStats,
  latestSoilForTalhao
} from "../assets/js/domain.js";

const state = {
  lancamentos: [
    {id:"r1",tipo:"receita",status:"pago",valor:1000,safraId:"s1"},
    {id:"d1",tipo:"despesa",status:"pago",valor:300,safraId:"s1"},
    {id:"d2",tipo:"despesa",status:"pendente",valor:200,safraId:"s2",vencimento:"2026-09-01"},
    {id:"r2",tipo:"receita",status:"pendente",valor:150,safraId:"s2"}
  ],
  colheitas:[
    {id:"c1",safraId:"s1",sacas:10},
    {id:"c2",safraId:"s2",sacas:5}
  ],
  vendas:[
    {id:"v1",safraId:"s1",sacas:4,total:4000},
    {id:"v2",safraId:"s2",sacas:2,total:1800}
  ],
  apanhas:[
    {id:"a1",data:"2026-08-01",safraId:"s1",talhaoId:"t1",trabalhadorId:"w1",latoes:100,valorLatao:1.5,status:"pago"},
    {id:"a2",data:"2026-08-02",safraId:"s1",talhaoId:"t1",trabalhadorId:"w1",latoes:80,valorLatao:1.5,status:"pendente"}
  ],
  lotes:[
    {id:"l1",safraId:"s1",alocacoes:[{apanhaId:"a1",latoes:60}]}
  ],
  trabalhadores:[{id:"w1",nome:"João"}],
  analisesSolo:[
    {id:"x1",talhaoId:"t1",data:"2026-01-01",ph:5.1},
    {id:"x2",talhaoId:"t1",data:"2026-05-01",ph:5.5}
  ]
};

test("resumo global não depende da safra ativa", () => {
  const r = calcGlobalSummary(state);
  assert.equal(r.saldo, 700);
  assert.equal(r.pagar, 200);
  assert.equal(r.receber, 150);
  assert.equal(r.produzido, 15);
  assert.equal(r.vendido, 6);
  assert.equal(r.estoque, 9);
});

test("resumo por safra", () => {
  const r = calcSafraSummary(state,"s1");
  assert.equal(r.receitas,1000);
  assert.equal(r.despesas,300);
  assert.equal(r.estoque,6);
  assert.equal(r.custoSaca,30);
});

test("contas a pagar permanecem globais", () => {
  const r = accountsPayableSummary(state,"2026-09-02");
  assert.equal(r.quantidade,1);
  assert.equal(r.total,200);
  assert.equal(r.vencido,200);
});

test("alocação do secador respeita quantidade parcial e ordem", () => {
  assert.equal(availableForApanha(state,state.apanhas[0]),40);
  const a = allocateLatoes(state,70,{safraId:"s1",talhaoId:"t1"});
  assert.deepEqual(a.alocacoes,[
    {apanhaId:"a1",latoes:40},
    {apanhaId:"a2",latoes:30}
  ]);
  assert.equal(a.faltante,0);
});

test("estoque por safra ignora venda em edição", () => {
  assert.equal(stockForSafra(state,"s1"),6);
  assert.equal(stockForSafra(state,"s1","v1"),10);
});

test("conta do colhedor", () => {
  const r=workerStats(state,"w1","s1");
  assert.equal(r.latoes,180);
  assert.equal(r.total,270);
  assert.equal(r.pago,150);
  assert.equal(r.pendente,120);
});

test("última análise de solo", () => {
  assert.equal(latestSoilForTalhao(state,"t1").id,"x2");
});
